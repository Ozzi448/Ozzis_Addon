local addonName, ns = ...

local OzzisAddon = LibStub("AceAddon-3.0"):GetAddon("OzzisAddon")
local OZM = OzzisAddon:NewModule("OZMedia", "AceConsole-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("OzzisAddon")
local LSM = LibStub("LibSharedMedia-3.0")
local AceDB = LibStub("AceDB-3.0")
if not OzzisAddon then return end

local mediaRegistered = false

if not LSM then
    ns:Print("LibSharedMedia-3.0 not found.")
    return
end

local Path = "Interface\\AddOns\\" .. addonName .. "\\Media\\"

local westAndRU = (LSM.LOCALE_BIT_ruRU or 0) + (LSM.LOCALE_BIT_western or 0)
local LatinCyrillicArabic = (LSM.LOCALE_BIT_arabic or 0) + (LSM.LOCALE_BIT_western or 0) + (LSM.LOCALE_BIT_ruRU or 0)

local function RegisterTextures()
    if not ns.TOXI then
        local textures = {
            { "Resting", "Resting.tga" },
        }
        for _, texture in ipairs(textures) do
            local name, file = unpack(texture)
            LSM:Register("texture", name, Path .. "Textures\\" .. file)
        end
    end
end

local function RegisterStatusBars()
    if not ns.TOXI then
        local statusbars = {
            { "Ozzi Arrow", "Arrow.tga" },
        }
        for _, statusbar in pairs(statusbars) do
            local name, file = unpack(statusbar)
            LSM:Register("state", name, Path .. "Textures\\" .. file)
        end
    end
end

local function RegisterFonts()
    local fonts = {
        { "Calibri", "calibri.ttf", LatinCyrillicArabic },
        { "Calibri Bold", "calibrib.ttf", LatinCyrillicArabic },
        { "Calibri Bold Italic", "calibriz.ttf", LatinCyrillicArabic },
        { "Calibri Italic", "calibrii.ttf", LatinCyrillicArabic },
        { "Calibri Light", "calibril.ttf", LatinCyrillicArabic },
        { "Calibri Light Italic", "calibrili.ttf", LatinCyrillicArabic },
        { "Century Gothic", "GOTHIC.ttf", LatinCyrillicArabic },
        { "Century Gothic Italic", "GOTHICI.ttf", LatinCyrillicArabic },
        { "Cronos Pro Regular", "cronospro-regular.otf" },
        { "Designosaur", "Designosaur.otf", westAndRU },
        { "Designosaur Italic", "Designosaur-Italic.otf", westAndRU },
        { "Eason Pro Regular", "Eason Pro Regular.otf" },
        { "Eason Pro Bold", "Eason Pro Bold.otf" },
        { "Enchanted Land", "Enchanted Land.otf" },
        { "Futura PT Book", "futura-pt-book.ttf", westAndRU },
        { "Imagine", "imagine.ttf" },
        { "Mark Pro", "Mark-Pro.otf" },
        { "Mark Pro Bold", "Mark-Pro-Bold.otf" },
        { "Mark Pro Medium", "MarkPro-Medium.otf" },
        { "Mark Pro Regular", "MarkPro-Regular.otf" },
        { "Montserrat Black", "Montserrat-Black.ttf", westAndRU },
        { "Montserrat Bold", "Montserrat-Bold.ttf", westAndRU },
        { "Montserrat ExtraBold", "Montserrat-ExtraBold.ttf", westAndRU },
        { "Montserrat ExtraLight", "Montserrat-ExtraLight.ttf", westAndRU },
        { "Montserrat Light", "Montserrat-Light.ttf", westAndRU },
        { "Montserrat Medium", "Montserrat-Medium.ttf", westAndRU },
        { "Montserrat Regular", "Montserrat-Regular.ttf", westAndRU },
        { "Montserrat SemiBold", "Montserrat-SemiBold.ttf", westAndRU },
        { "Montserrat Thin", "Montserrat-Thin.ttf", westAndRU },
        { "One Slice", "One Slice.otf" },
        { "PEPSI", "PEPSI.ttf" },
        { "Restiany", "Restiany.otf" },
        { "Roberto Condensed Bold", "RobotoCondensed-Bold.ttf", westAndRU },
        { "ROG", "ROG.otf" },
        { "Sanfransico Regular", "SFUIText-Regular.otf", westAndRU },
    }

    for _, font in ipairs(fonts) do
        LSM:Register("font", font[1], Path .. "Fonts\\" .. font[2], nil, font[3])
    end

    if not ns.GMFonts then
        local gmFonts = {
            { "Lauren Bold", "Lato-Bold.otf" },
            { "Lauren Bold Italic", "lauren-bold-italic.ttf" },
            { "Lauren Italic", "lauren-italic.otf" },
            { "Lauren Normal", "lauren-Normal.otf" },
            { "Lato", "Lato-Regular.ttf", westAndRU },
            { "Lato Bold", "Lato-Bold.ttf", westAndRU },
            { "Lato Italic", "Lato-Italic.ttf", westAndRU },
            { "Lato Bold Italic", "Lato-BoldItalic.ttf", westAndRU },
            { "Lato Thin", "Lato-Thin.ttf", westAndRU },
        }
        for _, font in ipairs(gmFonts) do
            LSM:Register("font", font[1], Path .. "Fonts\\" .. font[2], nil, font[3])
        end
    end

    if not (ns.ElvUI or ns.PA) then
        local elvFonts = {
            { "Action Man", "ElvUI\\ActionMan.ttf" },
            { "Continuum Medium", "ElvUI\\ContinuumMedium.ttf" },
            { "Die Die Die!", "ElvUI\\DieDieDie.ttf" },
            { "PT Sans Narrow", "ElvUI\\PTSansNarrow.ttf", westAndRU },
            { "Expressway", "ElvUI\\Expressway.ttf", westAndRU },
            { "Homespun", "ElvUI\\Homespun.ttf", westAndRU },
            { "Invisible", "ElvUI\\Invisible.ttf", westAndRU },
        }
        for _, font in ipairs(elvFonts) do
            LSM:Register("font", font[1], Path .. "Fonts\\" .. font[2], nil, font[3])
        end
    end
end

local function RegisterSounds()
    local sounds = {
        { "Carbonite", "QuestComplete.ogg" },
        { "Guild Wars 2 Message", "GW2Message.ogg" },
        { "Guild Wars 2 Email", "GW2Email.ogg" },
        { "Ion Skill Issue", "frankly.ogg" },
        { "iPhone Ding", "iphone-ding-sound.ogg" },
        { "iPhone Message Sent", "iphone-message-sent.ogg" },
        { "Oh Shit!", "oh-shit.ogg" },
        -- { "Shiny Woo", "Shiny Woo.ogg" },
        { "Loot Coin", "LootCoinSmall.ogg" },
        { "Map Ping", "MapPing.ogg" },
        { "Woooo Shines!", "Woooo Shines!.ogg" },
        { "Heartbeat 1", "heartbeat1.ogg" },
        { "Heartbeat 2", "heartbeat2.ogg" },
        { "Heartbeat 3", "heartbeat3.ogg" },
        { "Heartbeat 4", "heartbeat4.ogg" },
        { "Heartbeat 5", "heartbeat5.ogg" },
        { "Heartbeat 6", "heartbeat6.ogg" },
        { "Xalatath: Delicious!", "XalatathDelicious.ogg" },
        { "Xalatath: Enjoy That?", "XalatathEnjoyThat.ogg" },
        { "Xalatath: Every Little Death Helps", "XalatathEveryLittleDeathHelps.ogg" },
        { "Xalatath: Laugh 1", "XalatathLaugh.ogg" },
        { "Xalatath: Laugh 2", "XalatathLaugh2.ogg" },
        { "Xalatath: Laugh 3", "XalatathLaugh3.ogg" },
        { "Xalatath: Laugh 4", "XalatathLaugh4.ogg" },
        { "Xalatath: Shhh", "XalatathShhh.ogg" },
        { "Xalatath: Such Magnificence Awaits Us", "XalatathMagnificenceAwaitsUs.ogg" },
    }

    for _, sound in ipairs(sounds) do
        local name, file = unpack(sound)
        LSM:Register("sound", name, Path .. "Sounds\\" .. file)
    end
end

function OZM:OnInitialize()
    local db = OzzisAddon.db.profile

    if not OzzisAddon or not OzzisAddon.db then
        return
	end

    if OzzisAddon.db.profile.enableMedia then
        -- RegisterTextures()
        RegisterStatusBars()
        RegisterFonts()
        RegisterSounds()
        self:RegisterChatCommand("med", "Media")
    else
        self:DisableMediaFeatures()
    end
end

function OZM:OnEnable()
    if OzzisAddon.db.profile.enableMedia then
        self:EnableMedia()
    end
end

function OZM:OnDisable()
    if OzzisAddon.db.profile.enableMedia then
        self:UnregisterChatCommand("med")
        self:DisableMedia()
        ns:Print(L["Media module disabled."])
    end
end

function OZM:EnableMedia()
    -- ns:Print("Media module enabled.")
    if not mediaRegistered then
        RegisterFonts()
        RegisterSounds()
        mediaRegistered = true
    end
end

function OZM:DisableMedia()
    self:DisableMediaFeatures()
end

function OZM:DisableMediaFeatures()
    self:UnregisterChatCommand("med")
end

function OZM:Media(msg)
    msg = msg:lower()

    if msg == "font" then
        local fonts = LSM:List("font")
        ns:Print(L["Registered Fonts:"])
        for _, fontName in ipairs(fonts) do
            ns:Print("  • " .. fontName)
        end

    elseif msg == "sound" then
        local sounds = LSM:List("sound")
        ns:Print(L["Registered Sounds:"])
        for _, soundName in ipairs(sounds) do
            ns:Print("  • " .. soundName)
        end

    else
        ns:Print(L["Usage: /med font or /med sound"])
    end
end