local addonName, ns = ...

local OzzisAddon = LibStub("AceAddon-3.0"):GetAddon("OzzisAddon")
local Tracker = OzzisAddon:NewModule("Tracker", "AceConsole-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("OzzisAddon")
if not OzzisAddon then return end

local updateTicker, isLocked
local trackerEvents
local lastQuestID, lastQuestTitle

local trackerFrame = CreateFrame("Frame", "OzziTracker", UIParent, "BackdropTemplate")
trackerFrame:SetSize(250, 65)
trackerFrame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\Buttons\\White8x8",
    edgeSize = 1,
    insets = { left = 0, right = 0, top = 0, bottom = 0 }
})
trackerFrame:SetBackdropBorderColor(0, 0, 0, 0.5)
trackerFrame:SetMovable(true)
trackerFrame:EnableMouse(true)
trackerFrame:RegisterForDrag("LeftButton")
trackerFrame:Hide()

local function ApplySavedTrackerPosition()
    trackerFrame:ClearAllPoints()

    local pos = OzzisAddon.db and OzzisAddon.db.profile and OzzisAddon.db.profile.trackerPos
    if pos and pos.point and pos.relativePoint then
        local x = pos.x or 0
        local y = pos.y or 0
        trackerFrame:SetPoint(pos.point, UIParent, pos.relativePoint, x, y)
    else
        trackerFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    end
end

local posInit = CreateFrame("Frame")
posInit:RegisterEvent("PLAYER_LOGIN")
posInit:SetScript("OnEvent", function()
    ApplySavedTrackerPosition()
end)

trackerFrame:SetScript("OnDragStart", function(self)
    if not isLocked then self:StartMoving() end
end)

trackerFrame:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local point, _, relativePoint, xOfs, yOfs = self:GetPoint()
    OzzisAddon.db.profile.trackerPos = {
        point = point, relativePoint = relativePoint, x = xOfs, y = yOfs
    }
end)

local line1 = trackerFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalMed1")
line1:SetPoint("TOPLEFT", 10, -10)
local line2 = trackerFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalMed1")
line2:SetPoint("TOPLEFT", line1, "BOTTOMLEFT", 0, -4)
local line3 = trackerFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalMed1")
line3:SetPoint("TOPLEFT", line2, "BOTTOMLEFT", 0, -4)

local MIN_WIDTH = 200
local PADDING = 20

local function UpdateTracker()
    local mapID = C_Map.GetBestMapForUnit("player")
    local mapInfo = mapID and C_Map.GetMapInfo(mapID)
    local zone = mapInfo and mapInfo.name or "Unknown Zone"
    local subzone = GetSubZoneText() or "Unknown Subzone"

    local x, y = 0, 0
    if mapID then
        local pos = C_Map.GetPlayerMapPosition(mapID, "player")
        if pos then x, y = pos:GetXY() end
    end

    local function GetDifficultyShortName(difficultyID)
        return ns.diffMap[difficultyID] or "?"
    end

    if not ns.inInstance then
        line1:SetText(string.format("%.2f, %.2f", x * 100, y * 100))
        line2:SetText(string.format("%s (%d)", zone, mapID or 0))
        line3:SetText(subzone)
    else
        local instanceName, instanceType, difficultyID = GetInstanceInfo()
        local shortDiff = GetDifficultyShortName(difficultyID)

        if difficultyID == 208 then
            local delvesWidgetInfo = C_UIWidgetManager.GetScenarioHeaderDelvesWidgetVisualizationInfo(6183)
            local formattedTier = "Tier ?"
            if delvesWidgetInfo and delvesWidgetInfo.tierText then
                local tierNumber = delvesWidgetInfo.tierText:match("%d+")
                formattedTier = tierNumber and string.format("Tier %d", tonumber(tierNumber)) or delvesWidgetInfo.tierText
            end
            line1:SetText("------")
            line2:SetText(string.format("%s [Delve - %s] (%d)", zone, formattedTier, mapID))
            line3:SetText(subzone)
        else
            line1:SetText("------")
            line2:SetText(string.format("%s [%s] (%d)", zone, shortDiff, mapID))
            line3:SetText(subzone)
        end
    end

    local requiredWidth = math.max(
        line1:GetStringWidth(),
        line2:GetStringWidth(),
        line3:GetStringWidth()
    ) + PADDING

    trackerFrame:SetWidth(math.max(requiredWidth, MIN_WIDTH))
end

trackerFrame:SetScript("OnMouseUp", function(self, button)
    if button == "RightButton" then
        if lastQuestID and lastQuestTitle then
            ns:Print(string.format("|cffffff00%s|r (%d)", lastQuestTitle, lastQuestID))
        else
            ns:Print("|cffff0000" .. L["No recent quest accepted"] .. "|r")
        end
    end
end)

function Tracker:EnableTracker()
    trackerFrame:Show()
    updateTicker = C_Timer.NewTicker(1, UpdateTracker)
    isLocked = false

    if not trackerEvents then
        trackerEvents = CreateFrame("Frame")
        trackerEvents:SetScript("OnEvent", function(self, event, questID)
            if questID then
                lastQuestID = questID
                lastQuestTitle = C_QuestLog.GetTitleForQuestID(questID)
                C_Timer.After(0.1, function()
                    if QuestFrame and QuestFrame:IsShown() and QuestFrameDetailScrollChildEditBox then
                        QuestFrameDetailScrollChildEditBox:SetFocus()
                    end
                end)
            end
        end)
    end

    trackerEvents:RegisterEvent("QUEST_ACCEPTED")
end

function Tracker:DisableTracker()
    trackerFrame:Hide()
    if updateTicker then
        updateTicker:Cancel()
        updateTicker = nil
    end
    if trackerEvents and trackerEvents.UnregisterAllEvents then
        trackerEvents:UnregisterAllEvents()
    end
end

function Tracker:ToggleLock()
    isLocked = not isLocked
    ns:Print(isLocked and L["Tracker locked."] or L["Tracker unlocked. Drag to move."])
end

function Tracker:ResetPosition()
    OzzisAddon.db.profile.trackerPos = {
        point = "CENTER",
        relativePoint = "CENTER",
        x = 0,
        y = 0,
    }
    trackerFrame:ClearAllPoints()
    trackerFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
end

function Tracker:OnInitialize()
    if not OzzisAddon.db or not OzzisAddon.db.profile then
        return
    end

    OzzisAddon.db.profile.trackerPos = OzzisAddon.db.profile.trackerPos or {
        point = "CENTER",
        relativePoint = "CENTER",
        x = 0,
        y = 0,
    }

    if OzzisAddon.db.profile.enableTracker == nil then
        OzzisAddon.db.profile.enableTracker = true
    end
end

function Tracker:OnEnable()
    if OzzisAddon.db.profile.enableTracker then
        self:EnableTracker()
    else
        self:DisableTracker()
    end

    self:RegisterChatCommand("track", "HandleTracker")
end

function Tracker:OnDisable()
    self:DisableTracker()
    self:UnregisterChatCommand("track")
end

function Tracker:HandleTracker(input)
    if input == "on" then
        OzzisAddon.db.profile.enableTracker = true
        self:EnableTracker()
        ns:Print(L["Tracker Enabled"])
    elseif input == "off" then
        OzzisAddon.db.profile.enableTracker = false
        self:DisableTracker()
        ns:Print(L["Tracker disabled."])
    elseif input == "lock" then
        self:ToggleLock()
    elseif input == "reset" then
        self:ResetPosition()
        ns:Print(L["Tracker position has been reset."])
    else
        ns:Print(L["Usage: /track on | off | reset | lock"])
    end
end