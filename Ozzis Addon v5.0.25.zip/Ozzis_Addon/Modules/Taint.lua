local addonName, ns = ...
local OzzisAddon = LibStub("AceAddon-3.0"):GetAddon("OzzisAddon")
local Taint = OzzisAddon:NewModule("Taint", "AceConsole-3.0")

local function AllTrue(...)
    for i = 1, select("#", ...) do
        if not select(i, ...) then
            return false
        end
    end
    return true
end

if not AllTrue(ns.Retail, OzzisAddon, ns.IsCurrentExpansion) then
    return
end

function Taint:OnInitialize()
    self:RegisterChatCommand("oztaint", "ToggleTaint")
end

function Taint:OnEnable()
    ConsoleExec("taintLog 2")
	ns:Print("TaintLog enabled for debugging")

    ns:Print("Taint module **enabled** (/oztaint to toggle)")

    hooksecurefunc("UIDropDownMenu_Refresh", function()
        if InCombatLockdown() then return end

        for i = 1, UIDROPDOWNMENU_MAXLEVELS do
            local list = _G["DropDownList" .. i]
            if list and list:IsShown() then
                list:Hide()
            end
        end
    end)

    hooksecurefunc("GameTooltip_AddWidgetSet", function(tooltip, widgetSetID)
        if InCombatLockdown() then return end
        if widgetSetID ~= 1291 then return end

        local wc = tooltip.widgetContainer
        if wc then
            wc.dirty = true
            wc.shownWidgetCount = 0
        end
    end)

    hooksecurefunc("SetTooltipMoney", function(tooltip, money, anchorPoint, prefixText, suffixText)
        if InCombatLockdown() then return end
        for i = 1, 3 do
            local shoppingTip = _G["ShoppingTooltip" .. i]
            if shoppingTip then
                for j = 1, shoppingTip.numMoneyFrames or 0 do
                    local mf = _G[shoppingTip:GetName() .. "MoneyFrame" .. j]
                    if mf then
                        mf:Hide()
                    end
                end
            end
        end
    end)

    hooksecurefunc(GameTooltip, "SetBagItem", function()
        if InCombatLockdown() then return end

        for i = 1, 3 do
            local tip = _G["ShoppingTooltip" .. i]
            if tip and tip:IsShown() then
                tip:ClearLines()
                tip:Hide()
            end
        end
    end)

    hooksecurefunc("ContainerFrameItemButton_OnEnter", function()
        if InCombatLockdown() then return end
        if GameTooltip:IsShown() then
            GameTooltip:Show()
        end
    end)
end

function Taint:OnDisable()
    ns:Print("Taint module **disabled**.")
end

function Taint:ToggleTaint()
    if self:IsEnabled() then
        self:Disable()
        -- ns:Print("Taint module **disabled** (no more hooks active)")
    else
        self:Enable()
        ns:Print("Taint module **enabled**")
    end
end