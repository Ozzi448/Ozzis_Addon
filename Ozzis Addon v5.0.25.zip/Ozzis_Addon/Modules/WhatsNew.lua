local OzzisAddon = LibStub("AceAddon-3.0"):GetAddon("OzzisAddon")
local WN = OzzisAddon:NewModule("WhatsNew", "AceConsole-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("OzzisAddon")
if not OzzisAddon then return end

local frame
local function CreateWhatsNewFrame()
    if frame then return end

    frame = CreateFrame("Frame", "OzzisWhatsNewFrame", UIParent, "BackdropTemplate")
    frame:SetSize(800, 500)
    frame:SetResizable(true)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("TOOLTIP")
    frame:SetFrameLevel(100)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)

    frame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", --"Interface\\ChatFrame\\ChatFrameBackground",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        tile = false, tileSize = 0, edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    -- frame:SetBackdropColor(0., 0., 0, 0.5)
    frame:SetBackdropBorderColor(0, 0, 0, 0.5)

    local topBorder = frame:CreateTexture(nil, "BORDER")
    topBorder:SetColorTexture(0, 0, 0, 0.8)
    topBorder:SetHeight(1)
    topBorder:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0.8)
    topBorder:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)

    local resizeButton = CreateFrame("Button", nil, frame)
    resizeButton:SetSize(16, 16)
    resizeButton:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -2, 2)
    resizeButton:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    resizeButton:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    resizeButton:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    resizeButton:SetScript("OnMouseDown", function()
        frame:StartSizing("BOTTOMRIGHT")
    end)
    resizeButton:SetScript("OnMouseUp", function()
        frame:StopMovingOrSizing()
    end)

    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", frame, "TOP", 0, -10)
    title:SetText(L["What's New"])

    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetSize(24, 24)
    close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -5, -5)
    close:SetScript("OnClick", function()
        frame:Hide()
    end)

    local scrollFrame = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -40)
    scrollFrame:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -30, 10)

    local content = CreateFrame("Frame", nil, scrollFrame)
    content:SetSize(1, 1)
    scrollFrame:SetScrollChild(content)

    local text = content:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    text:SetJustifyH("LEFT")
    text:SetJustifyV("TOP")
    text:SetPoint("TOPLEFT")
    text:SetWidth(frame:GetWidth() - 50)
    content:SetHeight(1)
    content.text = text

    frame.text = text

    frame:SetScript("OnSizeChanged", function(self, width, height)
        local minW, minH = 300, 200
        if width < minW then self:SetWidth(minW) end
        if height < minH then self:SetHeight(minH) end

        scrollFrame:SetWidth(width - 40)
        scrollFrame:SetHeight(height - 50)
        text:SetWidth(width - 50)
    end)
end

function WN:WhatsNew()
    if not frame then
        CreateWhatsNewFrame()

        local updates = {
            "5.0.25",
            "• Added new Taint module.",
            "   • Added defensive taint mitigations inspired by legacy NoTaint behavior, focused on preventing addon involvement in known Blizzard taint paths.",
            "   • /oztaint toggle to enable/disable taint workarounds for testing and troubleshooting (enabled by default on login).",
            "   • Additional safeguards around Edit Mode access to avoid triggering known Blizzard unit frame taint conditions.",
            "• Changed.",
            "   • Tooltip handling refined to avoid interacting with money frames during combat.",
            "   • Tooltip-related hooks now bail early in combat to prevent taint propagation during item, inventory, and character panel hovers.",
            "• Fixed.",
            "   • Prevented addon participation in MoneyFrame_Update taint errors triggered by item tooltips (bags, character frame, action bars).",
            "   • Reduced false-positive taint attribution caused by addon-triggered UI refreshes during combat and Edit Mode transitions.",
            "• Known Limitations.",
            "   • Some Edit Mode–related taint errors originating from Blizzard unit frame code cannot be safely fixed from an addon and are left untouched.",
            "   • This addon intentionally avoids overriding or modifying protected Blizzard functions to prevent long-term UI instability.",
            "• Notes.",
            "   • These changes are defensive and conservative by design.",
            "   • The goal is to keep the UI usable during pre-patch instability while avoiding unsafe hooks or overrides.",
            "   • Some taint errors may still occur if they originate entirely within Blizzard code.",
            "5.0.24",
                "• Compatibility.",
                "   • Made the necessary changes according to the API for Midnight 12.0.0.",
            "5.0.23",
            "• Added a better way to check if the addon is loaded, and if it is not loaded, it will not continue to load.",
            "• Added better namespace elements.",
            L["• Bug Fixes."],
            "   • Fixed errors with Artifact slash command. (Retail Weapon, Underlight Angler, Heart of Azeroth, Legion Remix Artifact Weapon)",
            "   • Fixed TeleportOut /tp command to work with the new changes in 11.2.7 first prepatch for Midnight.",
            "   • Fixed LeaveGroup /lg command to work with the new changes in 11.2.7 first prepatch for Midnight.",
            "   • Fixed Locale issues, I will continue with re-writing the entire Locales later.",
            "   • Fixed a bug with the Tracker frame where it was not showing the correct instance difficulty.",
            L["5.0.22"],
            L["• Compatibility."],
            L["   • Made the necessary changes according to the API."],
            L["5.0.21"],
            L["• Bug Fixes."],
            L["   • Fixed a Lua error caused by accidentally copying code from unUS.lua to WhatsNew.lua without verification."],
            L["5.0.20"],
            L["• Updated Locale."],
            L["   • Updated all the Locales with all the changes I made, Sorry The Von."],
            L["5.0.19"],
            L["• Compatibility."],
            L["   • Added Nightfall Compatibility."],
            L["• Bug Fixes."],
            L["   • Fixed issues with Libs not loading correctly."],
            L["   • Fixed issues with slight lag with some modules like Tracker."],
            L["5.0.18"],
            L["• Bug Fixes"],
            L["   • Added TY! when you use /lg."],
            L["   • Fixed isses with Recorder not detecting correct Encounter info."],
            L["• Updated the Locale"],
            L["   • Upadted the Locale with every file and removed most symbols and spaces."],
            L["5.0.17"],
            L["• Added Legion Remix Commands."],
            L["   • Added /aui to open / close Artifact UI."],
            L["   • Added Auto Open Caches in Auto Settings, this can be enabled / disabled."],
            L["• Added CVar Settings."],
            L["   • Settings such as - maxFPS, GxAllowCachelessShaderMode, hwDetect, rawMouseEnable, mouseAcceleration, lootUnderMouse, AllowSoftwareRenererDX12."],
            L["5.0.16"],
            L["• Improved Chat Commands."],
            L["   • Added /dev to enable chat commands needed to get data."],
            L["   • Left relivant chat commands to normal use."],
            L["• Added new chat command /es and /est."],
            L["   • /es will tell you how many Ethereal Strands you have collected and how many total Ethereal Strands you can have."],
            L["   • /est will open up the Ethereal Strand Traits UI window if you complete campaign or use the skip on an alt."],
            L["• Added new Professions Bar Module"],
            L["   • You can type /profbar and it will toggle the professions bar frame on or off and you should see all trained professions and their levels."],
            L["• Added new settings window."],
            L["   • Dedicating to Ace libs to make my settings menu toggled with the use of /oz settings."],
            L["   • The settings window will now no longer in the ESC > Options > AddOns > OzzisAddon."],
            L["• Bug Fixes."],
            L["   • Fixed a bug with database and other inconsistencies."],
            L["   • Added an unregister event logic when modules get disabled, this should help with AddOn Memory Usage."],
            L["• Updated Tracker Instance Module."],
            L["   • Included PvP, Scenarios, Events, etc. to be tracked."],
            L["   • Added a right click ability on the Tracker Frame which will output with the Quest Title (QuestID)."],
            L["   • Tracker will automatically focus the recent quest."],
            L["v5.0.15"],
            L["• Added Instance Difficulty to Tracker."],
            L["   • Story was added to help determine instance type other than Raid."],
            L["• Bug Fixes."],
            L["   • Fixed a tracking bug."],
            L["v5.0.14"],
            L["• Added Settings in ESC > Options > AddOns"],
            L["   • You can now enable or disable Recorder / Tracker / Media Modules as well as accessing What's New by clicking the button as well as using the '/wn' slash command."],
            L["   • You can now enable or disable Loaded Message prompt in chat."],
            L["   • You can now enable or disable automatic quality of life tweaks such as auto minimap zoom out, Extra Action Button | Zone Button Style removal, and so on."],
            L["• Added New Slash Commands"],
            L["   • /oz help, /oz settings, /oz togglemsg | The main slash command is the 'settings' which is the same as the blizzard addon settings panel."],
            L["• Bug Fixes."],
            L["   • Fixed a bug with the Tracker Module where if it was disabled its still tracking the location in the backround causing unecessary memory usage."],
            L["   • Fixed the frame appearance and border issues with What's New."],
            L["   • Fixed the Tracker frame to report the correct tier level."],
            L["v5.0.13"],
            L["• Added What's New"],
            L["   • Accessible in-game using /wn."],
            L["• Added Locales"],
            L["   • The new locales should help change the text to the detected locale."],
            L["v5.0.12"],
            L["• Removed the Delve Tier that appears as 0 despite it being higher tier."],
            L["v5.0.11"],
            L["• Improved the Tracker frame"],
            L["   • It now appears without using /track on. The command still exists to help with toggling, e.g., /track off and then /track on."],
            L["   • Added 1px border to the tracking CoOrdinate frame."],
            L["   • CoOrdinates now appear with ----- whilst you are inside instances."],
            L["   • Added instance difficulty to appear as: 10N or 25H, etc. however, Delves may show as Delve 0, even if it is Tier 8."],
            L["• Improved Player Info"],
            L["   • /pli now shows phase reasons. This can help determine why a party member is phased."],
            L["v5.0.10"],
            L["• Compatibility."],
            L["   • Compatibility for 11.2.0 Patch"],
            L["• Bug Fixes"],
            L["   • Added postition of tracker frame to be saved to the saved variables, once the position is saved it should be in the same position across all characters on the account."],
            L["v5.0.9"],
            L["• Added version check, The addon will not continue to load if outside the current version."],
            L["• Removed the automatic recording of Quest Accept, Competion & Turn-ins as well as the recording of instance data and moved/improved this within the Recorder module."],
            L["v5.0.8"],
            L["• Added new slash command /window which toggles between windowed fullscreen and window mode."],
            L["v5.0.7"],
            L["• Added Tracker"],
            L["   • This tracker will show a moveable and lockable window that will show players current position, location (Zone and SubZone). When accepting quests, it outputs QuestName,QuestID, NPCName, NPCID, Zone, ZoneID, Location."],
            L["• Added Recorder"],
            L["   • This recorder can automatically record Quest Accept, Completion & Turn-ins. It automatically records Instance data. It records notes as well."],
            L["v5.0.6"],
            L["• Added fallbacks to safegurd from taints."],
            L["• Fixed addon print to allow multi line."],
            L["v5.0.5"],
            L["• Fixed AceConsole registration"],
            L["• Improved namespace"],
            L["• Added slash commands, /AC achievement check."],
            L["v5.0.4 - v1.0.0"],
            L["• Can't remember the notes."],
        }

        frame.text:SetText(table.concat(updates, "\n\n"))
        frame:Show()
        return
    end

    if frame:IsShown() then
        frame:Hide()
    else
        frame:Show()
    end
end

function WN:ShowWindow()
    WN:WhatsNew()
end

function WN:OnInitialize()
    WN:RegisterChatCommand("WN", "WhatsNew")
end
