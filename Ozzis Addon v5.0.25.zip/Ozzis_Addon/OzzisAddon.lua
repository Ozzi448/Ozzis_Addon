local addonName, ns = ...

_G["OzzisAddon"] = LibStub("AceAddon-3.0"):NewAddon("OzzisAddon", "AceConsole-3.0", "AceEvent-3.0")
local OzzisAddon = _G["OzzisAddon"]

local AC = LibStub("AceConfig-3.0")
local ACD = LibStub("AceConfigDialog-3.0")
local ACR = LibStub("AceConfigRegistry-3.0")
local ADB = LibStub("AceDB-3.0")
local AE = LibStub("AceEvent-3.0")
local AceGUI = LibStub("AceGUI-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("OzzisAddon")

local expectedVersion = "5.0.25"

OzzisAddon.defaults = {
	profile = {
		enableRecord = false,
		enableTracker = true,
		enableMedia = true,
		enableProfBar = true,
		showLoadedMessage = true,
		hideEB1Style = true,
		hideZAStyle = true,
		disablePlaterCVars = true,
		autoZoomOutMinimap = true,
		autoLootFix = true,
		autoOpenCaches = true,
		ProfBar = {
			isLocked = true,
		},
		trackerLocked = false,
		trackerPos = {
			point = "CENTER",
			relativePoint = "CENTER",
			x = 0,
			y = 0,
		},
	}
}

function OzzisAddon:OnInitialize()
	self.db = ADB:New("OzzisAddonDB", OzzisAddon.defaults, true)

    if ns.version ~= expectedVersion then
        ns:Print(L["IncompatibleVersion"] .. ": " .. tostring(ns.version) .. " (" .. L["Expected"] .. ": " .. expectedVersion .. ")")
        self.disabled = true
        return
    end
    if self.db and self.db.profile and self.db.profile.showLoadedMessage then
        ns:Print("v|cff00ff00" .. tostring(ns.version) .. "|r" .. " " .. L["Loaded successfully"] .. "." .. " " .. L["Use"] .. " |cffffffff/oz settings|r " .. L["to customise addon options."])
    end

    self:RegisterChatCommand("oz", "HandleSlashCommand")
    self:ApplySettings()
end

function OzzisAddon:OpenConfigWindow()
	local frame = AceGUI:Create("Frame")
	frame:SetTitle(L["Ozzis Addon"])
	-- frame:SetStatusText("Configure settings, modules and auto settings")
	frame:SetLayout("Fill")
	frame:SetWidth(600)
	frame:SetHeight(600)

    local tabGroup = AceGUI:Create("TabGroup")
    tabGroup:SetLayout("Flow")
	tabGroup:SetFullWidth(true)
	tabGroup:SetFullHeight(true)

    tabGroup:SetTabs({
        { text = L["General"], value = "general" },
        { text = L["Modules"], value = "modules" },
		{ text = L["Auto Settings"], value = "autoSettings" },
		{ text = L["CVars"], value = "CVars" },
    })

    tabGroup:SetCallback("OnGroupSelected", function(container, event, group)
		if not container then
			ns:Print(L["ERROR: container is nil"])
			return
		end

	    container:ReleaseChildren()

		local scrollFrame = AceGUI:Create("ScrollFrame")
		scrollFrame:SetLayout("Flow")
		scrollFrame:SetFullWidth(true)
		scrollFrame:SetFullHeight(true)
		container:AddChild(scrollFrame)

		if group == "general" then
            frame:SetStatusText(L["General Settings"])
        elseif group == "modules" then
            frame:SetStatusText(L["Configure your Modules"])
        elseif group == "autoSettings" then
            frame:SetStatusText(L["Configure Auto Load Settings"])
		elseif group == "CVars" then
			frame:SetStatusText(L["Configure CVar settings"])
        end

        if group == "general" then
            local generalLabel = AceGUI:Create("Label")
            generalLabel:SetText(L["OzzisAddon is a lightweight, modular addon built to streamline your UI experience. It includes features such as combat recording, tracking, rare detection alerts (sound and chat), and media enhancements. You can also toggle visibility for Extra Action and Zone Ability buttons, disable script and addon profiling, prevent Plater CVar enforcement, auto zoom out your minimap, and fix the auto loot bug — all fully configurable in the settings."])
            generalLabel:SetFontObject(GameFontHighlightMedium)
            generalLabel:SetFullWidth(true)
            scrollFrame:AddChild(generalLabel)

			local spacer = AceGUI:Create("Label")
			spacer:SetText(" ")
			spacer:SetFullWidth(true)
			scrollFrame:AddChild(spacer)

            local whatsNewButton = AceGUI:Create("Button")
            whatsNewButton:SetText(L["Show What's New"])
            whatsNewButton:SetFullWidth(false)
            whatsNewButton:SetCallback("OnClick", function()
                OzzisAddon:GetModule("WhatsNew"):ShowWindow()
            end)
            scrollFrame:AddChild(whatsNewButton)
        elseif group == "modules" then
            local label = AceGUI:Create("Label")
            label:SetText(L["If one or more modules has been enabled or disabled, the UI will need to be reloaded, please if you make a change, click the reload button."])
			label:SetFontObject(GameFontHighlightMedium)
            label:SetFullWidth(true)
            scrollFrame:AddChild(label)

			local spacer2 = AceGUI:Create("Label")
			spacer2:SetText(" ")
			spacer2:SetFullWidth(true)
			scrollFrame:AddChild(spacer2)

			local enableRecord = AceGUI:Create("CheckBox")
			enableRecord:SetLabel(L["Enable Record Module"])
			-- enableRecord:SetDescription(L["Toggle the Record module on or off."])
			enableRecord:SetValue(OzzisAddon.db.profile.enableRecord)
			enableRecord:SetFullWidth(true)

			enableRecord:SetCallback("OnValueChanged", function(widget, event, value)
				OzzisAddon.db.profile.enableRecord = value
				if value then
					OzzisAddon:EnableModuleByName("Recorder")
				else
					OzzisAddon:DisableModuleByName("Recorder")
				end
			end)

			enableRecord.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(enableRecord.frame, "ANCHOR_RIGHT")
				GameTooltip:SetText(L["Toggle the Record module on or off."])
				GameTooltip:Show()
			end)

			enableRecord.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			scrollFrame:AddChild(enableRecord)

			local enableTracker = AceGUI:Create("CheckBox")
			enableTracker:SetLabel(L["Enable Tracker Module"])
			-- enableTracker:SetDescription(L["Toggle the Tracker module on or off."])
			enableTracker:SetValue(OzzisAddon.db.profile.enableTracker)
			enableTracker:SetFullWidth(true)

			enableTracker:SetCallback("OnValueChanged", function(widget, event, value)
				OzzisAddon.db.profile.enableTracker = value
				if value then
					OzzisAddon:EnableModuleByName("Tracker")
				else
					OzzisAddon:DisableModuleByName("Tracker")
				end
			end)

			enableTracker.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(enableTracker.frame, "ANCHOR_RIGHT")
				GameTooltip:SetText(L["Toggle the Tracker module on or off."])
				GameTooltip:Show()
			end)

			enableTracker.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			scrollFrame:AddChild(enableTracker)

			local enableMedia = AceGUI:Create("CheckBox")
			enableMedia:SetLabel(L["Enable Media Module"])
			-- enableMedia:SetDescription(L["Toggle the Media module on or off."])
			enableMedia:SetValue(OzzisAddon.db.profile.enableMedia)
			enableMedia:SetFullWidth(true)

			enableMedia:SetCallback("OnValueChanged", function(widget, event, value)
				OzzisAddon.db.profile.enableMedia = value
				if value then
					OzzisAddon:EnableModuleByName("OZMedia")
				else
					OzzisAddon:DisableModuleByName("OZMedia")
				end
			end)

			enableMedia.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(enableMedia.frame, "ANCHOR_RIGHT")
				GameTooltip:SetText(L["Toggle the media features on or off."])
				GameTooltip:Show()
			end)

			enableMedia.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			scrollFrame:AddChild(enableMedia)

			local enableProfBar = AceGUI:Create("CheckBox")
			enableProfBar:SetLabel(L["Enable Profession Bar Module"])
			enableProfBar:SetValue(OzzisAddon.db.profile.enableProfBar)
			enableProfBar:SetFullWidth(true)

			enableProfBar:SetCallback("OnValueChanged", function(widget, event, value)
				OzzisAddon.db.profile.enableProfBar = value
				if value then
					OzzisAddon:EnableModuleByName("ProfBar")
				else
					OzzisAddon:DisableModuleByName("ProfBar")
				end
			end)

			enableProfBar.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(enableProfBar.frame, "ANCHOR_RIGHT")
				GameTooltip:SetText(L["Toggle the Profession Bar Module on or off."])
				GameTooltip:Show()
			end)

			enableProfBar.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			scrollFrame:AddChild(enableProfBar)

			local reloadUIButton = AceGUI:Create("Button")
            reloadUIButton:SetText(L["Reload UI"])
            reloadUIButton:SetFullWidth(false)
            reloadUIButton:SetCallback("OnClick", function()
                ReloadUI()
            end)
            scrollFrame:AddChild(reloadUIButton)
        elseif group == "autoSettings" then
            local label = AceGUI:Create("Label")
            label:SetText(L["If one or more setting has been enabled or disabled, the UI will need to be reloaded, please if you make a change, click the reload button."])
			label:SetFontObject(GameFontHighlightMedium)
            label:SetFullWidth(true)
            scrollFrame:AddChild(label)

			local spacer3 = AceGUI:Create("Label")
			spacer3:SetText(" ")
			spacer3:SetFullWidth(true)
			scrollFrame:AddChild(spacer3)

            local loadedToggle = AceGUI:Create("CheckBox")
            loadedToggle:SetLabel(L["Show 'Loaded Successfully' Message"])
            loadedToggle:SetValue(OzzisAddon.db.profile.showLoadedMessage)
            loadedToggle:SetFullWidth(true)
            loadedToggle:SetCallback("OnValueChanged", function(widget, event, value)
                OzzisAddon.db.profile.showLoadedMessage = value
            end)

			loadedToggle.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(loadedToggle.frame, "ANCHOR_RIGHT")
				GameTooltip:SetText(L["Toggle whether to show the startup message in chat."])
				GameTooltip:Show()
			end)

			loadedToggle.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

            scrollFrame:AddChild(loadedToggle)

			local hideEB1Style = AceGUI:Create("CheckBox")
			hideEB1Style:SetLabel(L["Hide Extra Action Button Style"])
			-- hideEB1Style:SetDescription(L["Automatically hides the Extra Action Button style frame on login if it's visible."])
			hideEB1Style:SetFullWidth(true)

			hideEB1Style:SetValue(OzzisAddon.db.profile.hideEB1Style)

			hideEB1Style:SetCallback("OnValueChanged", function(widget, event, value)
				OzzisAddon.db.profile.hideEB1Style = value
			end)

			hideEB1Style.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(hideEB1Style.frame, "ANCHOR_RIGHT")
				GameTooltip:SetText(L["Automatically hides the Extra Action Button style frame on login if it's visible."])
				GameTooltip:Show()
			end)

			hideEB1Style.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			scrollFrame:AddChild(hideEB1Style)

			local hideZAStyle = AceGUI:Create("CheckBox")
			hideZAStyle:SetLabel(L["Hide Zone Ability Button Style"])
			-- hideZAStyle:SetDescription(L["Automatically hides the Zone Ability style frame on login if it's visible."])
			hideZAStyle:SetFullWidth(true)

			hideZAStyle:SetValue(OzzisAddon.db.profile.hideZAStyle)

			hideZAStyle:SetCallback("OnValueChanged", function(widget, event, value)
				OzzisAddon.db.profile.hideZAStyle = value
			end)

			hideZAStyle.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(hideZAStyle.frame, "ANCHOR_RIGHT")
				GameTooltip:SetText(L["Automatically hides the Zone Ability style frame on login if it's visible."])
				GameTooltip:Show()
			end)

			hideZAStyle.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			scrollFrame:AddChild(hideZAStyle)

			local disablePlaterCVars = AceGUI:Create("CheckBox")
			disablePlaterCVars:SetLabel(L["Disable Plater CVar Enforcement"])
			-- disablePlaterCVars:SetDescription(L["Prevents Plater from enforcing its own CVar settings on login. Requires UI reload."])
			disablePlaterCVars:SetFullWidth(true)

			disablePlaterCVars:SetValue(OzzisAddon.db.profile.disablePlaterCVars)

			disablePlaterCVars:SetCallback("OnValueChanged", function(widget, event, value)
				OzzisAddon.db.profile.disablePlaterCVars = value
			end)

			disablePlaterCVars.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(disablePlaterCVars.frame, "ANCHOR_RIGHT")
				GameTooltip:SetText(L["Prevents Plater from enforcing its own CVar settings on login. Requires UI reload."])
				GameTooltip:Show()
			end)

			disablePlaterCVars.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			scrollFrame:AddChild(disablePlaterCVars)

			local autoZoomOutMinimap = AceGUI:Create("CheckBox")
			autoZoomOutMinimap:SetLabel(L["Auto Zoom Out Minimap"])
			-- autoZoomOutMinimap:SetDescription(L["Automatically sets the minimap zoom to maximum distance (zoomed out) on login."])
			autoZoomOutMinimap:SetFullWidth(true)

			autoZoomOutMinimap:SetValue(OzzisAddon.db.profile.autoZoomOutMinimap)

			autoZoomOutMinimap:SetCallback("OnValueChanged", function(widget, event, value)
				OzzisAddon.db.profile.autoZoomOutMinimap = value
			end)

			autoZoomOutMinimap.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(autoZoomOutMinimap.frame, "ANCHOR_RIGHT")
				GameTooltip:SetText(L["Automatically sets the minimap zoom to maximum distance (zoomed out) on login."])
				GameTooltip:Show()
			end)

			autoZoomOutMinimap.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			scrollFrame:AddChild(autoZoomOutMinimap)

			local autoLootFix = AceGUI:Create("CheckBox")
			autoLootFix:SetLabel(L["Fix Auto Loot Bug"])
			-- autoLootFix:SetDescription(L["Force Auto Loot when loot window opens (bypasses UI bug)"])
			autoLootFix:SetFullWidth(true)

			autoLootFix:SetValue(OzzisAddon.db.profile.autoLootFix)

			autoLootFix:SetCallback("OnValueChanged", function(widget, event, value)
				OzzisAddon.db.profile.autoLootFix = value
			end)

			autoLootFix.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(autoLootFix.frame, "ANCHOR_RIGHT")
				GameTooltip:SetText(L["Force Auto Loot when loot window opens (bypasses UI bug)"])
				GameTooltip:Show()
			end)

			autoLootFix.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			scrollFrame:AddChild(autoLootFix)

			local seasonID = PlayerGetTimerunningSeasonID()
			if seasonID == 2 then
				local autoOpenCaches = AceGUI:Create("CheckBox")
				autoOpenCaches:SetLabel(L["Auto Open Caches"])
				autoOpenCaches:SetFullWidth(true)

				autoOpenCaches:SetValue(OzzisAddon.db.profile.autoOpenCaches)

				autoOpenCaches:SetCallback("OnValueChanged", function(widget, event, value)
					OzzisAddon.db.profile.autoOpenCaches = value
				end)

				autoOpenCaches.frame:SetScript("OnEnter", function()
					GameTooltip:SetOwner(autoOpenCaches.frame, "ANCHOR_RIGHT")
					GameTooltip:SetText(L["Automatically Open Looted Caches"])
					GameTooltip:Show()
				end)

				autoOpenCaches.frame:SetScript("OnLeave", function()
					GameTooltip:Hide()
				end)

				scrollFrame:AddChild(autoOpenCaches)
			else
				return
			end

			local reloadUIButton2 = AceGUI:Create("Button")
            reloadUIButton2:SetText(L["Reload UI"])
            reloadUIButton2:SetFullWidth(false)
            reloadUIButton2:SetCallback("OnClick", function()
                ReloadUI()
            end)
			scrollFrame:AddChild(reloadUIButton2)
        elseif group == "CVars" then
			frame:SetStatusText(L["Conficure CVar Settings."])

            local label = AceGUI:Create("Label")
            label:SetText(L["Some CVars that can be useful to help with performance and or quality of life. CVars that require reloading ui will be marked with a * CVars that require restarting the graphics drivers will be marked with **."])
			label:SetFontObject(GameFontHighlightMedium)
            label:SetFullWidth(true)
            scrollFrame:AddChild(label)

			local spacer4 = AceGUI:Create("Label")
			spacer4:SetText(" ")
			spacer4:SetFullWidth(true)
			scrollFrame:AddChild(spacer4)

			local maxFPSInput = AceGUI:Create("EditBox")
			maxFPSInput:SetLabel("maxFPS")
			maxFPSInput:SetText(GetCVar("maxFPS"))
			maxFPSInput:SetFullWidth(true)
			maxFPSInput:SetCallback("OnEnterPressed", function(widget, event, value)
				local num = tonumber(value)
				if num and num > 0 and num <= 1000 then
					SetCVar("maxFPS", value)
					ns:Print(L["maxFPS set to"] .. " " .. value)
				else
					ns:Print(L["Invalid value. Enter a number between 1 and 1000."])
				end
			end)

			maxFPSInput.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(maxFPSInput.frame, "ANCHOR_RIGHT")
				GameTooltip:SetText(L["Set the maximum frame rate of your monitor e.g. 144 for 144 hz (1-1000)."])
				GameTooltip:Show()
			end)

			maxFPSInput.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			scrollFrame:AddChild(maxFPSInput)

			local allowCacheless = AceGUI:Create("EditBox")
			allowCacheless:SetLabel("GxAllowCachelessShaderMode **")
			allowCacheless:SetText(GetCVar("GxAllowCachelessShaderMode"))
			allowCacheless:SetFullWidth(true)
			allowCacheless:SetCallback("OnEnterPressed", function(widget, event, value)
				local num = tonumber(value)
				if num == 0 or num == 1 then
					SetCVar("GxAllowCachelessShaderMode", value)
					ns:Print(L["GxAllowCachelessShaderMode set to"] .. " " .. value)
				else
					ns:Print(L["Invalid value. Enter 1 to enable or 0 to disable."])
				end
			end)

			allowCacheless.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(allowCacheless.frame, "ANCHOR_RIGHT")
				GameTooltip:SetText(L["CPU Memory Saving Mode: Loads shaders from disk on demand. May delay first-time object appearance. Best used with SSDs. Graphics Driver Restart is Required."])
				GameTooltip:Show()
			end)

			allowCacheless.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			scrollFrame:AddChild(allowCacheless)

			local hwDetect = AceGUI:Create("EditBox")
			hwDetect:SetLabel("hwDetect *")
			hwDetect:SetText(GetCVar("hwDetect"))
			hwDetect:SetFullWidth(true)
			hwDetect:SetCallback("OnEnterPressed", function(widget, event, value)
				local num = tonumber(value)
				if num == 0 or num == 1 then
					SetCVar("hwDetect", value)
					ns:Print(L["hwDetect set to"] .. " " .. value)
				else
					ns:Print(L["Invalid value. Enter 1 to enable or 0 to disable."])
				end
			end)

			hwDetect.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(hwDetect.frame, "ANCHOR_RIGHT")
				GameTooltip:SetText(L["Enable to detect hardware for best configuration. Reload UI is Required."])
				GameTooltip:Show()
			end)

			hwDetect.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			scrollFrame:AddChild(hwDetect)

			local rawMouseEnable = AceGUI:Create("EditBox")
			rawMouseEnable:SetLabel("rawMouseEnable *")
			rawMouseEnable:SetText(GetCVar("rawMouseEnable"))
			rawMouseEnable:SetFullWidth(true)
			rawMouseEnable:SetCallback("OnEnterPressed", function(widget, event, value)
				local num = tonumber(value)
				if num == 0 or num == 1 then
					SetCVar("rawMouseEnable", value)
					ns:Print(L["rawMouseEnable set to"] .. " " .. value)
				else
					ns:Print(L["Invalid value. Enter 1 to enable or 0 to disable."])
				end
			end)

			rawMouseEnable.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(rawMouseEnable.frame, "ANCHOR_RIGHT")
				GameTooltip:SetText(L["Enables raw mouse input, which reads mouse movement directly from the hardware, bypassing OS and driver customizations like mouse acceleration. Reload UI is Required."])
				GameTooltip:Show()
			end)

			rawMouseEnable.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			scrollFrame:AddChild(rawMouseEnable)

			local mouseAcceleration = AceGUI:Create("EditBox")
			mouseAcceleration:SetLabel("mouseAcceleration *")
			mouseAcceleration:SetText(GetCVar("mouseAcceleration"))
			mouseAcceleration:SetFullWidth(true)
			mouseAcceleration:SetCallback("OnEnterPressed", function(widget, event, value)
				local num = tonumber(value)
				if num == -1 or num == 1 or num == 0 then
					SetCVar("mouseAcceleration", value)
					ns:Print(L["mouseAcceleration set to"] .. " " .. value)
				else
					ns:Print(L["Invalid value. Enter -1 to use desktop acceleration or 0 to disable mouse acceleration or 1 to enable mouse acceleration."])
				end
			end)

			mouseAcceleration.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(mouseAcceleration.frame, "ANCHOR_RIGHT")
				GameTooltip:SetText(L["-1: use desktop mouse acceleration, 0: disable mouse acceleration, 1: enable mouse acceleration. (Default -1)"])
				GameTooltip:Show()
			end)

			mouseAcceleration.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			scrollFrame:AddChild(mouseAcceleration)

			local lootUnderMouse = AceGUI:Create("EditBox")
			lootUnderMouse:SetLabel("lootUnderMouse *")
			lootUnderMouse:SetText(GetCVar("lootUnderMouse"))
			lootUnderMouse:SetFullWidth(true)
			lootUnderMouse:SetCallback("OnEnterPressed", function(widget, event, value)
				local num = tonumber(value)
				if num == 0 or num == 1 then
					SetCVar("lootUnderMouse", value)
					ns:Print(L["lootUnderMouse set to"] .. " " .. value)
				else
					ns:Print(L["Invalid value. Enter 1 to enable or 0 to disable."])
				end
			end)

			lootUnderMouse.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(lootUnderMouse.frame, "ANCHOR_RIGHT")
				GameTooltip:ClearAllPoints()
				GameTooltip:SetText(L["Whether the loot window should open under the mouse."])
				GameTooltip:Show()
			end)

			lootUnderMouse.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			scrollFrame:AddChild(lootUnderMouse)

			local AllowSoftwareRendererDX12 = AceGUI:Create("EditBox")
			AllowSoftwareRendererDX12:SetLabel("AllowSoftwareRendererDX12 *")
			AllowSoftwareRendererDX12:SetText(GetCVar("AllowSoftwareRendererDX12"))
			AllowSoftwareRendererDX12:SetFullWidth(true)
			AllowSoftwareRendererDX12:SetCallback("OnEnterPressed", function(widget, event, value)
				local num = tonumber(value)
				if num == 0 or num == 1 then
					SetCVar("AllowSoftwareRendererDX12", value)
					ns:Print(L["AllowSoftwareRendererDX12 set to"] .. " " .. value)
				else
					ns:Print(L["Invalid value. Enter 1 to enable or 0 to disable."])
				end
			end)

			AllowSoftwareRendererDX12.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(AllowSoftwareRendererDX12.frame, "ANCHOR_RIGHT")
				GameTooltip:ClearAllPoints()
				GameTooltip:SetText(L["DX11 software render is used by default, due to issues with the DX12 software renderer"])
				GameTooltip:Show()
			end)

			AllowSoftwareRendererDX12.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			scrollFrame:AddChild(AllowSoftwareRendererDX12)

			local rolesGroup = AceGUI:Create("InlineGroup")
			rolesGroup:SetTitle(L["Selected Roles (Read Only)"])
			rolesGroup:SetFullWidth(true)
			rolesGroup:SetLayout("Flow")

			local function CreateRoleCheckbox(name, bitFlag)
				local cb = AceGUI:Create("CheckBox")
				cb:SetLabel(name)
				cb:SetDisabled(true)
				cb:SetWidth(100)
				cb.bitFlag = bitFlag
				rolesGroup:AddChild(cb)
				return cb
			end

			local cbTank   = CreateRoleCheckbox("Tank", 2)
			local cbHealer = CreateRoleCheckbox("Healer", 4)
			local cbDPS    = CreateRoleCheckbox("DPS", 8)
			local cbLeader = CreateRoleCheckbox("Leader", 1)

			local function UpdateRoleCheckboxes()
				local val = tonumber(GetCVar("lfgSelectedRoles")) or 0
				cbLeader:SetValue(bit.band(val, 1) ~= 0)
				cbTank:SetValue(bit.band(val, 2) ~= 0)
				cbHealer:SetValue(bit.band(val, 4) ~= 0)
				cbDPS:SetValue(bit.band(val, 8) ~= 0)
			end

			UpdateRoleCheckboxes()

			rolesGroup.frame:SetScript("OnEnter", function()
				GameTooltip:SetOwner(rolesGroup.frame, "ANCHOR_RIGHT")
				GameTooltip:SetText(L["Displays your currently selected LFG roles (read-only)."])
				GameTooltip:Show()
			end)
			rolesGroup.frame:SetScript("OnLeave", function()
				GameTooltip:Hide()
			end)

			C_Timer.NewTicker(2, UpdateRoleCheckboxes)

			scrollFrame:AddChild(rolesGroup)

			local reloadUIButton3 = AceGUI:Create("Button")
            reloadUIButton3:SetText(L["Reload UI"])
            reloadUIButton3:SetFullWidth(false)
            reloadUIButton3:SetCallback("OnClick", function()
                C_UI.Reload()
            end)
			scrollFrame:AddChild(reloadUIButton3)

			local restartGxButton = AceGUI:Create("Button")
            restartGxButton:SetText(L["Restart Gx"])
            restartGxButton:SetFullWidth(false)
            restartGxButton:SetCallback("OnClick", function()
                RestartGx()
            end)
			scrollFrame:AddChild(restartGxButton)
		end
    end)

    frame:AddChild(tabGroup)
    tabGroup:SelectTab("general")
end

function OzzisAddon:EnableModuleByName(name)
	local mod = self:GetModule(name, true)
	if mod and not mod:IsEnabled() then
		self:EnableModule(name)
		ns:Print(name .. " " .. L["module enabled."])
	end
end

function OzzisAddon:DisableModuleByName(name)
	local mod = self:GetModule(name, true)
	if mod and mod:IsEnabled() then
		self:DisableModule(name)
		ns:Print(name .. " " .. L["module disabled."])
	end
end

function OzzisAddon:ApplySettings()
	if OzzisAddon.db.profile.enableRecord then self:EnableModule("Recorder") else self:DisableModule("Recorder") end
	if OzzisAddon.db.profile.enableTracker then self:EnableModule("Tracker") else self:DisableModule("Tracker") end
	if OzzisAddon.db.profile.enableMedia then self:EnableModule("OZMedia") else self:DisableModule("OZMedia") end
	if OzzisAddon.db.profile.enableProfBar then self:EnableModule("ProfBar") else self:DisableModule("ProfBar") end
end

local commandHandlers = {
	help = function()
		ns:Print(L["Ozzi Addon Commands:"])
		ns:Print(L["/oz help - Show this help message"])
		ns:Print(L["/oz settings - Open the settings panel"])
		ns:Print(L["/oz togglemsg - Toggle startup message"])
		ns:Print(L["/r - Manage or check your current raid and legacy raid difficulty settings"])
		ns:Print(L["/d - Manage or check your current dungeon difficulty settings"])
		ns:Print(L["/em - Toggle the Edit Mode on or off"])
		ns:Print(L["/es - Show your Ethereal Strands count and the total possible amount"])
		ns:Print(L["/est - Toggle the Ethereal Strands Trait UI window anywhere in the world"])
		ns:Print(L["/darkmaul - Check amount of daily Mawshrooms looted and turnins to Darkmaul."])
		ns:Print(L["/dusklight - Check amount of daily eggs looted and turnins to Nest, 10th turnin the Matriarch will fly down for you to claim the mount."])
		ns:Print(L["/lg - Leave your current group instantly"])
		ns:Print(L["/tp - Teleport out of your current instance or delve"])
		ns:Print(L["/ri - Reset all instances you're eligible to reset"])
		ns:Print(L["/qc - Check if a quest ID is completed; shows ID, clickable title for details, and notes if it's a campaign"])
		ns:Print(L["/ac - Check if an achievement is completed; shows name, ID, and clickable link for details"])
		ns:Print(L["/window - Toggle between windowed fullscreen and windowed mode"])
		ns:Print(L["/clear - Clear chat history from all channels"])
		if ns.devModeEnabled then
			ns:Print(L["/npc - Show the selected NPC or player's ID, name, and location"])
			ns:Print(L["/build - Show your game version, build number, and release info"])
			ns:Print(L["/fs - Toggle the Frame Stack tooltip display"])
			ns:Print(L["/co - Show your current map's name and ID, or with “wmf” get the open world map's name and ID"])
		end
		if not (ns.ElvUI or ns.TukUI or ns.GW2UI) then
			ns:Print(L["/rl - Reload the UI if ElvUI, Tukui, or GW2UI is not loaded"])
		else
			return
		end
	end,

	settings = function()
		OzzisAddon:OpenConfigWindow()
	end,

	togglemsg = function()
		local current = OzzisAddon.db.profile.showLoadedMessage
		OzzisAddon.db.profile.showLoadedMessage = not current
		ns:Print(string.format(L["Startup message is now"] .. " " .. "%s", OzzisAddon.db.profile.showLoadedMessage and L["enabled"] or L["disabled"]))
	end,
}

function OzzisAddon:HandleSlashCommand(input)
	local cmd, rest = input:match("^(%S*)%s*(.-)$")
	cmd = cmd:lower()

	if commandHandlers[cmd] then
		commandHandlers[cmd](rest)
	else
		ns:Print(L["Unknown command. Type /oz help for a list of commands."])
	end
end