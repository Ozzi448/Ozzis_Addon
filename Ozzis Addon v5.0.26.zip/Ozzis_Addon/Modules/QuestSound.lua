local addonName, ns = ...
local OzzisAddon = LibStub("AceAddon-3.0"):GetAddon("OzzisAddon")
local QuestSound = OzzisAddon:NewModule("QuestSound", "AceEvent-3.0", "AceConsole-3.0")

if not (ns.Retail and ns.IsCurrentExpansion) then return end

local LSM = LibStub("LibSharedMedia-3.0")
local questState = {}

function QuestSound:OnEnable()
    self:RegisterEvent("QUEST_LOG_UPDATE")
    self:RegisterEvent("QUEST_TURNED_IN")

    self:ScanQuestLog(true)
    initialized = true

    -- ns:Print("QuestSound enabled")
end

function QuestSound:OnDisable()
    self:UnregisterEvent("QUEST_LOG_UPDATE")
    self:UnregisterEvent("QUEST_TURNED_IN")
    wipe(questState)
end

function QuestSound:QUEST_LOG_UPDATE()
    self:ScanQuestLog(false)
end

function QuestSound:QUEST_TURNED_IN(event, questID)
    questState[questID] = nil
end

function QuestSound:ScanQuestLog(isInit)
    if not OzzisAddon.db.profile.questSoundEnabled then return end

    local key = OzzisAddon.db.profile.questSoundKey or "Carbonite"
    local channel = OzzisAddon.db.profile.questSoundChannel or "Master"
    local soundPath = LSM:Fetch("sound", key)
    if not soundPath then return end

    local numEntries = C_QuestLog.GetNumQuestLogEntries()

    for index = 1, numEntries do
        local info = C_QuestLog.GetInfo(index)
        if info and not info.isHeader and info.questID then
            local questID = info.questID
            local isCompleteNow = C_QuestLog.IsComplete(questID) and true or false
            local wasComplete = questState[questID]

            if not isInit and isCompleteNow and not wasComplete then
                PlaySoundFile(soundPath, channel)
            end

            questState[questID] = isCompleteNow
        end
    end
end