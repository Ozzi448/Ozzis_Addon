local addonName, ns = ...
local OzzisAddon = LibStub("AceAddon-3.0"):GetAddon("OzzisAddon")
local Taint = OzzisAddon:NewModule("Taint", "AceConsole-3.0")

local function AllTrue(...)
    for i = 1, select("#", ...) do
        if not select(i, ...) then
            return false
        end
    end
    return true
end

if not AllTrue(ns.Retail, OzzisAddon, ns.IsCurrentExpansion) then
    return
end

local function dropdownCleanup()
    if InCombatLockdown() then return end

    for i = 1, UIDROPDOWNMENU_MAXLEVELS do
        local list = _G["DropDownList" .. i]
        if list and list:IsShown() then
            list:Hide()
        end
    end
end

local function widgetSetCleanup(tooltip, widgetSetID)
    if InCombatLockdown() then return end
    if widgetSetID ~= 1291 then return end

    local wc = tooltip.widgetContainer
    if wc then
        wc.dirty = true
        wc.shownWidgetCount = 0
    end
end

local function tooltipMoneyCleanup(tooltip, money, anchorPoint, prefixText, suffixText)
    if InCombatLockdown() then return end
    for i = 1, 3 do
        local shoppingTip = _G["ShoppingTooltip" .. i]
        if shoppingTip then
            for j = 1, shoppingTip.numMoneyFrames or 0 do
                local mf = _G[shoppingTip:GetName() .. "MoneyFrame" .. j]
                if mf then
                    mf:Hide()
                end
            end
        end
    end
end

local function bagItemCleanup(self)
    if InCombatLockdown() then return end

    for i = 1, 3 do
        local tip = _G["ShoppingTooltip" .. i]
        if tip and tip:IsShown() then
            tip:ClearLines()
            tip:Hide()
        end
    end
end

local function containerOnEnterCleanup(self)
    if InCombatLockdown() then return end
    if GameTooltip:IsShown() then
        GameTooltip:Show()
    end
end

function Taint:OnInitialize()
    -- self:RegisterChatCommand("oztaint", "ToggleTaint")
end

function Taint:OnEnable()
    local f = CreateFrame("Frame")
    f:RegisterEvent("PLAYER_LOGIN")
    f:SetScript("OnEvent", function()

        local function NormalizeOutOfRange(frame)
            if not frame or frame:IsForbidden() or not frame.unit then return end
    
            if frame.outOfRange == nil then
                local inRange = UnitInRange(frame.unit)
                frame.outOfRange = (inRange == false)
            end
        end
    
        hooksecurefunc("CompactUnitFrame_UpdateInRange", NormalizeOutOfRange)
        hooksecurefunc("CompactUnitFrame_SetUnit", NormalizeOutOfRange)
    end)
    -- ConsoleExec("taintLog 2")
    -- ns:Print("TaintLog enabled for debugging")

    -- ns:Print("Taint module **enabled**")

    hooksecurefunc("UIDropDownMenu_Refresh", dropdownCleanup)
    hooksecurefunc("GameTooltip_AddWidgetSet", widgetSetCleanup)
    hooksecurefunc("SetTooltipMoney", tooltipMoneyCleanup)
    hooksecurefunc(GameTooltip, "SetBagItem", bagItemCleanup)
    hooksecurefunc("ContainerFrameItemButton_OnEnter", containerOnEnterCleanup)
end

function Taint:OnDisable()
    ns:Print("Taint module **disabled**")
end

-- function Taint:ToggleTaint()
--     if self:IsEnabled() then
--         self:Disable()
--         -- ns:Print("Taint module **disabled** (no more hooks active)")
--     else
--         self:Enable()
--         ns:Print("Taint module **enabled**")
--     end
-- end