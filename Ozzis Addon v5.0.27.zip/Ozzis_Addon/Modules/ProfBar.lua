local addonName, ns = ...

local OzzisAddon = LibStub("AceAddon-3.0"):GetAddon("OzzisAddon")
local ProfBar = OzzisAddon:NewModule("ProfBar", "AceConsole-3.0", "AceEvent-3.0")
local AceDB = LibStub("AceDB-3.0")
if not OzzisAddon then return end

local profFrame
local selectedScopeID = nil
local pendingScopeID = nil

function ProfBar:OnInitialize()
    self.db = OzzisAddon.db.profile.ProfBar
    self:CreateProfessionsFrame()
end

function ProfBar:CreateProfessionsFrame()
    profFrame = CreateFrame("Frame", "OzzisProfessionsFrame", UIParent, "BackdropTemplate")
    profFrame:SetSize(300, 200)
    profFrame:SetPoint("CENTER")
    profFrame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\Buttons\\White8x8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    -- profFrame:SetBackdropColor(0, 0, 0, 0.5)
    profFrame:SetBackdropBorderColor(0, 0, 0, 0.5)

    profFrame:SetMovable(true)
    profFrame:EnableMouse(true)
    profFrame:RegisterForDrag("LeftButton")
    profFrame:SetScript("OnDragStart", function(frame)
        if not ProfBar.db or not ProfBar.db.isLocked then frame:StartMoving() end
    end)
    profFrame:SetScript("OnDragStop", function(frame)
        frame:StopMovingOrSizing()
    end)

    profFrame:Hide()
end

function ProfBar:UpdateProfessionsDisplay()
    if not profFrame then return end

    for _, child in ipairs({ profFrame:GetChildren() }) do
        child:Hide()
    end

    profFrame:Show()
    local yOffset = -20

    local function createBar(name, rank, maxRank)
        local bar = CreateFrame("StatusBar", nil, profFrame, "BackdropTemplate")
        bar:SetSize(260, 20)
        bar:SetPoint("TOPLEFT", 20, yOffset)
        bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
        bar:SetMinMaxValues(0, maxRank)
        bar:SetValue(rank)
        bar:SetStatusBarColor(0.2, 0.6, 1)
        bar:Show()

        bar:SetBackdrop({
            bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile = true, tileSize = 16, edgeSize = 16,
            insets = { left = 4, right = 4, top = 4, bottom = 4 }
        })
        bar:SetBackdropColor(0, 0, 0, 0.5)

        local label = bar:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        label:SetPoint("LEFT", bar, "LEFT", 5, 0)
        label:SetText(string.format("%s: %d/%d", name, rank, maxRank))

        yOffset = yOffset - 30
    end

    if selectedScopeID then
        local scopeInfo = C_TradeSkillUI.GetProfessionInfoBySkillLineID(selectedScopeID)
        if scopeInfo and scopeInfo.professionName then
            createBar(scopeInfo.professionName, scopeInfo.professionRank or 0, scopeInfo.professionMaxRank or 150)
        else
            ns:Print(L["Failed to retrieve profession info for scope ID:"] .. " " .. selectedScopeID)
        end
    else
        local profs = { GetProfessions() }
        for _, profIndex in ipairs(profs) do
            if profIndex then
                local name, _, rank, maxRank = GetProfessionInfo(profIndex)
                createBar(name, rank, maxRank)
            end
        end
    end
end

-- function ProfBar:ShowProfessionScope(scopeName)
--     local terms = { strsplit(" ", scopeName:lower()) }

--     local function matchesAll(professionName, parentName)
--         local fullName = (parentName or "") .. " " .. (professionName or "")
--         fullName = fullName:lower()
--         for _, term in ipairs(terms) do
--             if not fullName:find(term, 1, true) then return false end
--         end
--         return true
--     end

--     local allScopes = C_TradeSkillUI.GetAllProfessionTradeSkillLines()
--     for _, skillLineID in ipairs(allScopes) do
--         local scopeInfo = C_TradeSkillUI.GetProfessionInfoBySkillLineID(skillLineID)

--         if scopeInfo and scopeInfo.professionName and scopeInfo.professionMaxRank and scopeInfo.professionMaxRank > 0 then
--             if matchesAll(scopeInfo.professionName, scopeInfo.parentName) then
--                 pendingScopeID = skillLineID
--                 ns:Print("Matched: " .. (scopeInfo.parentName or "") .. " " .. scopeInfo.professionName)
--                 C_TradeSkillUI.OpenTradeSkill(skillLineID)
--                 return
--             end
--         end
--     end

--     ns:Print("No trained profession scope found for: " .. scopeName)
-- end

function ProfBar:ToggleLock()
    self.db.isLocked = not self.db.isLocked
    ns:Print(self.db.isLocked and L["ProfBar locked."] or L["ProfBar unlocked. Drag to move."])
end

function ProfBar:HandleProfBarCommand(input)
    input = input and input:lower() or ""

    if input == "" then
        self:ToggleProfFrame()
    elseif "lock" then
        self:ToggleLock()
    else
        ns:Print(L["Usage:"])
        ns:Print("/profbar —" .. " " .. L["toggle professions frame"])
        ns:Print("/profbar lock —" .. " " .. L["toggles lock"])
    end
end

function ProfBar:OnEnable()
    self:RegisterEvent("TRADE_SKILL_SHOW", "OnTradeSkillReady")
    self:RegisterChatCommand("profbar", "HandleProfBarCommand")
end

function ProfBar:OnDisable()
    self:UnregisterAllEvents()
    self:UnregisterChatCommand("profbar")
end

function ProfBar:ToggleProfFrame()
    if profFrame:IsShown() then
        profFrame:Hide()
    else
        self:UpdateProfessionsDisplay()
    end
end

function ProfBar:OnTradeSkillReady()
    if pendingScopeID then
        selectedScopeID = pendingScopeID
        pendingScopeID = nil

        C_Timer.After(0.1, function()
            self:UpdateProfessionsDisplay()
        end)
    end
end