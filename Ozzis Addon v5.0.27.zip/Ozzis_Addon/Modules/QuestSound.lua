local addonName, ns = ...

local OzzisAddon = LibStub("AceAddon-3.0"):GetAddon("OzzisAddon")
local QuestSound = OzzisAddon:NewModule("QuestSound", "AceEvent-3.0", "AceConsole-3.0")
local LSM = LibStub("LibSharedMedia-3.0")
local DGV = DugisGuideViewer

local questState = {}

local function dropdownCleanup()
    if InCombatLockdown() then return end

    for i = 1, UIDROPDOWNMENU_MAXLEVELS do
        local list = _G["DropDownList" .. i]
        if list and list:IsShown() then
            list:Hide()
        end
    end
end

local function EnsureQuestCompleteSoundNone()
    if DugisGuideViewer and DugisGuideViewer.db and DugisGuideViewer.db.profile then
        local questCompleteSound = DugisGuideViewer.db.profile.char.settings[DGV_QUESTCOMPLETESOUND]
        
        if questCompleteSound.checked ~= 1 then
            questCompleteSound.checked = 1
            
            local currentText
            for _, opt in ipairs(questCompleteSound.options) do
                if opt.value == questCompleteSound.checked then
                    currentText = opt.text
                    break
                end
            end
            
            ns:Print("Dugi Guides 'Quest Complete Sound' is now:", currentText or questCompleteSound.checked)
        end
    end
end

function QuestSound:OnEnable()
    self:RegisterEvent("QUEST_LOG_UPDATE")
    self:RegisterEvent("QUEST_TURNED_IN")

    self:ScanQuestLog(true)
    initialized = true

    -- if ns.Dugi then
    --     EnsureQuestCompleteSoundNone()
    -- end
    -- ns:Print("QuestSound enabled")
end

function QuestSound:OnDisable()
    self:UnregisterEvent("QUEST_LOG_UPDATE")
    self:UnregisterEvent("QUEST_TURNED_IN")
    wipe(questState)
end

function QuestSound:QUEST_LOG_UPDATE()
    self:ScanQuestLog(false)
end

function QuestSound:QUEST_TURNED_IN(event, questID)
    questState[questID] = nil
end

function QuestSound:ScanQuestLog(isInit)
    if not OzzisAddon.db.profile.questSoundEnabled then return end

    local key = OzzisAddon.db.profile.questSoundKey or "Carbonite"
    local channel = OzzisAddon.db.profile.questSoundChannel or "Master"
    local soundPath = LSM:Fetch("sound", key)
    if not soundPath then return end

    local numEntries = C_QuestLog.GetNumQuestLogEntries()

    for index = 1, numEntries do
        local info = C_QuestLog.GetInfo(index)
        if info and not info.isHeader and info.questID then
            local questID = info.questID
            local isCompleteNow = C_QuestLog.IsComplete(questID) and true or false
            local wasComplete = questState[questID]

            if not isInit and isCompleteNow and not wasComplete then
                PlaySoundFile(soundPath, channel)
            end

            questState[questID] = isCompleteNow
        end
    end
end
