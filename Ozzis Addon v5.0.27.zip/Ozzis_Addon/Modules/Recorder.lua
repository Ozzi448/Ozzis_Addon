local addonName, ns = ...
local OzzisAddon = LibStub("AceAddon-3.0"):GetAddon("OzzisAddon")
if not OzzisAddon then return end

local Recorder = OzzisAddon:NewModule("Recorder", "AceConsole-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("OzzisAddon")

local recorderEnabled = false
local frame = CreateFrame("Frame")

local function OneLine(s)
    s = tostring(s or "")
    s = s:gsub("[\r\n]+", " ")
    s = s:gsub("%s%s+", " ")
    return s
end

local function EscapePipes(s)
    if not s then return "" end
    s = s:gsub("||", "||||")
    s = s:gsub("|", "||")
    return s
end

if ns.Retail then

    local logFrame = CreateFrame("Frame", "RecorderLogFrame", UIParent, "BasicFrameTemplateWithInset")
    logFrame:SetSize(600, 600)
    logFrame:SetPoint("CENTER")
    logFrame:Hide()
    logFrame:SetMovable(true)
    logFrame:SetResizable(true)
    logFrame:SetResizeBounds(400, 200, 1000, 800)
    logFrame:SetClampedToScreen(true)
    logFrame:EnableMouse(true)
    logFrame:RegisterForDrag("LeftButton")
    logFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    logFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)

    local titleParent = logFrame.TitleBg or logFrame
    logFrame.title = logFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    logFrame.title:SetPoint("LEFT", titleParent, "LEFT", 5, 0)
    logFrame.title:SetText(L["Recorder Log"])

    local scrollFrame = CreateFrame("ScrollFrame", nil, logFrame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 10, -50)
    scrollFrame:SetPoint("BOTTOMRIGHT", -30, 40)

    local editBox = CreateFrame("EditBox", nil, scrollFrame)
    editBox:SetMultiLine(true)
    editBox:SetFontObject("ChatFontNormal")
    editBox:SetAutoFocus(false)
    editBox:EnableMouse(true)
    editBox:SetWidth(540)
    editBox:SetScript("OnEscapePressed", editBox.ClearFocus)
    editBox:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
    editBox:SetScript("OnMouseDown", function(self) if not self:HasFocus() then self:SetFocus() end end)
    scrollFrame:SetScrollChild(editBox)

    local clearBtn = CreateFrame("Button", nil, logFrame, "UIPanelButtonTemplate")
    clearBtn:SetSize(80, 18)
    clearBtn:SetPoint("RIGHT", titleParent, "RIGHT", -25, 0)
    clearBtn:SetText(L["Clear"])
    clearBtn:SetScript("OnClick", function()
        RecorderDB.Record = {}
        editBox:SetText("")
        ns:Print(L["Record log has been cleared."])
    end)

    local resizer = CreateFrame("Button", nil, logFrame)
    resizer:SetPoint("BOTTOMRIGHT", logFrame, "BOTTOMRIGHT", -6, 7)
    resizer:SetSize(16, 16)
    resizer:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    resizer:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    resizer:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    resizer:SetScript("OnMouseDown", function(self, button)
        if button == "LeftButton" then
            logFrame:StartSizing("BOTTOMRIGHT")
            local ht = self:GetHighlightTexture()
            if ht then ht:Hide() end
        end
    end)
    resizer:SetScript("OnMouseUp", function(self, button)
        if button == "LeftButton" then
            logFrame:StopMovingOrSizing()
            local ht = self:GetHighlightTexture()
            if ht then ht:Show() end
        end
    end)

    scrollFrame:SetScript("OnSizeChanged", function(_, width, height)
        if width and width > 40 then editBox:SetWidth(width - 20) end
        if height and height > 40 then editBox:SetHeight(height - 20) end
    end)

    local function UpdateLogWindow()
        if not RecorderDB or not RecorderDB.Record then
            editBox:SetText("")
            return
        end

        local out = {}

        for i = 1, #RecorderDB.Record do
            local line = RecorderDB.Record[i]
            if type(line) == "string" then
                table.insert(out, EscapePipes(line))
            end
        end

        for k, v in pairs(RecorderDB.Record) do
            if type(k) == "number" and type(v) == "table" and not out[k] then
                table.insert(out, string.format("-- MapTextureTable: ArtID=%d", k))
                for key2, value2 in pairs(v) do
                    table.insert(out, string.format("  [%s] = %s", tostring(key2), tostring(value2)))
                end
            end
        end

        if #out > 0 then
            editBox:SetText(table.concat(out, "\n"))
            editBox:HighlightText(0, 0)
        else
            editBox:SetText("")
        end
    end

    local function GetTargetNPC()
        local npcName = UnitName("target")
        local guid = UnitGUID("target")
        local npcID
        if guid then
            local _, _, _, _, _, id = strsplit("-", guid)
            npcID = tonumber(id)
        end
        return npcName, npcID
    end

    local function FormatCoords(zoneID)
        local pos = C_Map.GetPlayerMapPosition(zoneID or 0, "player")
        if not pos then return 0, 0 end
        local x, y = pos:GetXY()
        return x * 100, y * 100
    end

    local function AddQuestEntry(prefix, questID, questName)
        local zoneID = C_Map.GetBestMapForUnit("player") or 0
        local mapInfo = C_Map.GetMapInfo(zoneID)
        local zoneName = mapInfo and mapInfo.name or "Unknown Zone"
        local x, y = FormatCoords(zoneID)
        local npcName, npcID = GetTargetNPC()
        local entry
        if prefix == "A" or prefix == "T" then
            entry = string.format(
                "%s %s |QID|%d|N|Speak to %s in {%s} (%.2f,%.2f)|Z|%d|NPC|%s|",
                prefix,
                OneLine(questName),
                questID,
                OneLine(npcName or "Unknown"),
                OneLine(zoneName),
                x, y,
                zoneID,
                npcID or "?"
            )
        elseif prefix == "C" then
            if C_QuestLog and type(C_QuestLog.GetQuestObjectives) == "function" then
                local objectives = C_QuestLog.GetQuestObjectives(questID)
                if objectives and #objectives > 0 then
                    for i, obj in ipairs(objectives) do
                        local t = obj.text or ("Objective " .. i)
                        local progress = ""
                        if obj.numRequired and obj.numRequired > 0 then progress = string.format(" (%d/%d)", obj.numFulfilled or 0, obj.numRequired) end
                        local qidx = string.format("%d.%d", questID, i)
                        entry = string.format(
                            "%s %s |QID|%s|N|%s%s in {%s} (%.2f,%.2f)|Z|%d|",
                            prefix,
                            OneLine(questName),
                            qidx,
                            OneLine(t),
                            progress,
                            OneLine(zoneName),
                            x, y,
                            zoneID
                        )
                        entry = OneLine(entry)
                        RecorderDB.Record = RecorderDB.Record or {}
                        table.insert(RecorderDB.Record, entry)
                    end
                else
                    entry = string.format(
                        "%s %s |QID|%d|N|Objective in {%s} (%.2f,%.2f)|Z|%d|",
                        prefix,
                        OneLine(questName),
                        questID,
                        OneLine(zoneName),
                        x, y,
                        zoneID
                    )
                    entry = OneLine(entry)
                    RecorderDB.Record = RecorderDB.Record or {}
                    table.insert(RecorderDB.Record, entry)
                end
            end
        end
        entry = OneLine(entry)
        RecorderDB.Record = RecorderDB.Record or {}
        table.insert(RecorderDB.Record, entry)
        UpdateLogWindow()
    end

    function Recorder:HandleEvent(event, ...)
        if not recorderEnabled then return end

        if event == "PLAYER_ENTERING_WORLD" then
            C_Timer.After(2, function()
                local instanceName, _, difficultyID, _, _, _, _, instanceID = GetInstanceInfo()
                local mapID = C_Map.GetBestMapForUnit("player")
                local _, _, _, difficultyName = GetInstanceInfo()
                local difficultyLabel = difficultyName or "Unknown"
                if not mapID or not instanceID or mapID == 0 or instanceID == 0 then return end
                local entry = string.format(
                    "-- |N|%s Instance Entered - %s [%s] (instanceID=%d)|Z|%d|",
                    OneLine(instanceName or "Unknown"),
                    OneLine(instanceName or "Unknown"),
                    difficultyLabel,
                    instanceID,
                    mapID
                )
                entry = OneLine(entry)
                RecorderDB.Record = RecorderDB.Record or {}
                table.insert(RecorderDB.Record, entry)
                UpdateLogWindow()
            end)
            return
        end

        if event == "ENCOUNTER_START" then
            local encounterID, bossName, bossNPCID = ...
            if not encounterID or not bossName then return end
            local zoneID = C_Map.GetBestMapForUnit("player") or 0
            local mapInfo = C_Map.GetMapInfo(zoneID)
            local zoneName = (mapInfo and mapInfo.name) or "Unknown Zone"
            local _, _, _, difficultyName = GetInstanceInfo()
            local difficultyLabel = difficultyName or "Unknown"
            local entry = string.format(
                "-- |N|Encounter Started - %s [%s] (encounterID=%d), BossName=%s, BossID=%s in {%s}|Z|%d|NPC|%s|",
                OneLine(bossName),
                difficultyLabel,
                encounterID,
                OneLine(bossName),
                tostring(bossNPCID or "?"),
                OneLine(zoneName),
                zoneID,
                tostring(bossNPCID or "?")
            )
            RecorderDB.Record = RecorderDB.Record or {}
            table.insert(RecorderDB.Record, entry)
            UpdateLogWindow()
            return
        end

        if event == "SCENARIO_UPDATE" then
            local stageName, stageDescription, numCriteria = C_Scenario.GetStepInfo()
            local scenarioName, currentStage, numStages = C_Scenario.GetInfo()
            if stageName and stageDescription then
                RecorderDB.Record = RecorderDB.Record or {}
                table.insert(RecorderDB.Record, string.format("-- Stage %d/%d", currentStage or 0, numStages or 0))
                table.insert(RecorderDB.Record, string.format("-- Stage Name - %s", OneLine(stageName)))
                table.insert(RecorderDB.Record, string.format("-- Stage Goal - %s", OneLine(stageDescription)))
                UpdateLogWindow()
            end
        end

        if event == "SCENARIO_CRITERIA_UPDATE" then
            local stageName, stageDescription, numCriteria = C_Scenario.GetStepInfo()
            local scenarioName, currentStage, numStages = C_Scenario.GetInfo()
            if stageName and stageDescription then
                RecorderDB.Record = RecorderDB.Record or {}
                table.insert(RecorderDB.Record, string.format("-- Stage %d/%d", currentStage or 0, numStages or 0))
                table.insert(RecorderDB.Record, string.format("-- Stage Name - %s", OneLine(stageName)))
                table.insert(RecorderDB.Record, string.format("-- Stage Goal - %s", OneLine(stageDescription)))
                UpdateLogWindow()
            end
            if numCriteria and numCriteria > 0 then
                for index = 1, numCriteria do
                    local criteriaString, criteriaType, completed, quantity, totalQuantity, flags, assetID, quantityString, criteriaID, duration, elapsed, _, isWeightedProgress = C_ScenarioInfo.GetCriteriaInfo(index)
                    if completed and criteriaID then
                        local zoneID = C_Map.GetBestMapForUnit("player") or 0
                        local x, y = FormatCoords(zoneID)
                        local mapInfo = C_Map.GetMapInfo(zoneID)
                        local zoneName = (mapInfo and mapInfo.name) or "Unknown Zone"
                        local entry = string.format(
                            "C %s |SID|%d|Z|%d| -- %s (%.2f, %.2f)",
                            OneLine(criteriaString or "Unknown Criteria"),
                            criteriaID,
                            zoneID,
                            OneLine(zoneName),
                            x, y
                        )
                        RecorderDB.Record = RecorderDB.Record or {}
                        table.insert(RecorderDB.Record, entry)
                    end
                end
                UpdateLogWindow()
            end
        end

        if event == "QUEST_ACCEPTED" or event == "QUEST_COMPLETE" or event == "QUEST_AUTOCOMPLETE" or event == "QUEST_TURNED_IN" then
            local questID = ...
            if not questID or questID == 0 then
                local count = C_QuestLog.GetNumQuestLogEntries()
                for i = 1, count do
                    local info = C_QuestLog.GetInfo(i)
                    if info and (info.isCompleted or info.isAutoComplete) then questID = info.questID break end
                end
            end
            if not questID or questID == 0 then return end
            local questName = C_QuestLog.GetTitleForQuestID(questID) or "Unknown Quest"
            local prefix = event == "QUEST_ACCEPTED" and "A" or (event == "QUEST_TURNED_IN" and "T" or "C")
            AddQuestEntry(prefix, questID, questName)
            return
        end
    end

    function Recorder:OnInitialize()
        RecorderDB = RecorderDB or {}
        RecorderDB.Record = RecorderDB.Record or {}
        RecorderDB.enabled = RecorderDB.enabled ~= false
    end

    function Recorder:OnEnable()
        self:RegisterChatCommand("rec", "HandleRecorder")
    end

    function Recorder:OnDisable()
        frame:UnregisterAllEvents()
        self:UnregisterChatCommand("rec")
    end

    function Recorder:EnableRecorder()
        recorderEnabled = true
        ns:Print(L["Recorder enabled."])
    end

    function Recorder:DisableRecorder()
        frame:UnregisterAllEvents()
        recorderEnabled = false
        ns:Print(L["Recorder disabled."])
    end

    -- function Recorder:HandleRecorder(input)
    --     if input == "on" then
    --         Recorder:EnableRecorder()
    --     elseif input == "off" then
    --         Recorder:DisableRecorder()
    --     elseif input == "clear" then
    --         RecorderDB.Record = {}
    --         ns:Print(L["Record log has been cleared."])
    --         UpdateLogWindow()
    --     elseif input == "log" then
    --         if logFrame:IsShown() then logFrame:Hide() else UpdateLogWindow() logFrame:Show() end
    --     elseif input and input:sub(1, 5) == "note " then
    --         local noteText = input:sub(6)
    --         if noteText and noteText ~= "" then
    --             RecorderDB.Record = RecorderDB.Record or {}
    --             local zoneID = C_Map.GetBestMapForUnit("player") or 0
    --             local x, y = FormatCoords(zoneID)
    --             local mapInfo = C_Map.GetMapInfo(zoneID)
    --             local zoneName = (mapInfo and mapInfo.name) or "Unknown Zone"
    --             local formattedNote = string.format(
    --                 "-- |N|%s in {%s} (%.2f, %.2f)|Z|%d|",
    --                 OneLine(noteText),
    --                 OneLine(zoneName),
    --                 x, y,
    --                 zoneID
    --             )
    --             formattedNote = OneLine(formattedNote)
    --             table.insert(RecorderDB.Record, formattedNote)
    --             ns:Print(L["Note added."])
    --             UpdateLogWindow()
    --         else
    --             ns:Print(L["Usage: /rec note <your message>"])
    --         end
    --     elseif input == "npc" then
    --         local npcName, npcID = GetTargetNPC()
    --         if npcName and npcID then
    --             local zoneID = C_Map.GetBestMapForUnit("player") or 0
    --             local x, y = FormatCoords(zoneID)
    --             local mapInfo = C_Map.GetMapInfo(zoneID)
    --             local zoneName = mapInfo and mapInfo.name or "Unknown Zone"
    --             local dump = string.format(
    --                 "-- |N|%s (npc:%s) in {%s} (%.2f, %.2f)|Z|%d|NPC|%s|",
    --                 OneLine(npcName),
    --                 tostring(npcID or "?"),
    --                 OneLine(zoneName),
    --                 x, y,
    --                 zoneID,
    --                 tostring(npcID or "?")
    --             )
    --             RecorderDB.Record = RecorderDB.Record or {}
    --             table.insert(RecorderDB.Record, dump)
    --             ns:Print("NPC info added.")
    --             UpdateLogWindow()
    --         else
    --             ns:Print("No NPC targeted.")
    --         end
    --     elseif input == "gossip" then
    --         if C_GossipInfo and C_GossipInfo.GetOptions then
    --             local options = C_GossipInfo.GetOptions()
    --             if options and #options > 0 then
    --                 RecorderDB.Record = RecorderDB.Record or {}
    --                 for i, opt in ipairs(options) do
    --                     local line = string.format(
    --                         "-- |N|Gossip Info - %d, %s, %s|",
    --                         i,
    --                         OneLine(opt.name or "Unknown"),
    --                         tostring(opt.gossipOptionID or "nil")
    --                     )
    --                     table.insert(RecorderDB.Record, line)
    --                 end
    --                 ns:Print("Gossip info added.")
    --                 UpdateLogWindow()
    --             else
    --                 ns:Print("No gossip options available.")
    --             end
    --         else
    --             ns:Print("Gossip API not available.")
    --         end
    --     else
    --         ns:Print(L["Usage: /rec on | off | clear | log | note <your message>"])
    --     end
    -- end
    function Recorder:HandleRecorder(input)
        if input == "on" then
            Recorder:EnableRecorder()
        elseif input == "off" then
            Recorder:DisableRecorder()
        elseif input == "clear" then
            RecorderDB.Record = {}
            ns:Print(L["Record log has been cleared."])
            UpdateLogWindow()
        elseif input == "log" then
            if logFrame:IsShown() then logFrame:Hide() else UpdateLogWindow() logFrame:Show() end
        elseif input and input:sub(1, 5) == "note " then
            local noteText = input:sub(6)
            if noteText and noteText ~= "" then
                RecorderDB.Record = RecorderDB.Record or {}
                local zoneID = C_Map.GetBestMapForUnit("player") or 0
                local x, y = FormatCoords(zoneID)
                local mapInfo = C_Map.GetMapInfo(zoneID)
                local zoneName = (mapInfo and mapInfo.name) or "Unknown Zone"
                local formattedNote = string.format(
                    "-- |N|%s in {%s} (%.2f, %.2f)|Z|%d|",
                    OneLine(noteText),
                    OneLine(zoneName),
                    x, y,
                    zoneID
                )
                formattedNote = OneLine(formattedNote)
                table.insert(RecorderDB.Record, formattedNote)
                ns:Print(L["Note added."])
                UpdateLogWindow()
            else
                ns:Print(L["Usage: /rec note <your message>"])
            end
        elseif input == "npc" then
            local npcName, npcID = GetTargetNPC()
            if npcName and npcID then
                local zoneID = C_Map.GetBestMapForUnit("player") or 0
                local x, y = FormatCoords(zoneID)
                local mapInfo = C_Map.GetMapInfo(zoneID)
                local zoneName = mapInfo and mapInfo.name or "Unknown Zone"
                local dump = string.format(
                    "-- |N|%s (npc:%s) in {%s} (%.2f, %.2f)|Z|%d|NPC|%s|",
                    OneLine(npcName),
                    tostring(npcID or "?"),
                    OneLine(zoneName),
                    x, y,
                    zoneID,
                    tostring(npcID or "?")
                )
                RecorderDB.Record = RecorderDB.Record or {}
                table.insert(RecorderDB.Record, dump)
                ns:Print(L["NPC info added."])
                UpdateLogWindow()
            else
                ns:Print(L["No NPC targeted."])
            end
        elseif input == "gossip" then
            if C_GossipInfo and C_GossipInfo.GetOptions then
                local options = C_GossipInfo.GetOptions()
                if options and #options > 0 then
                    RecorderDB.Record = RecorderDB.Record or {}
                    for i, opt in ipairs(options) do
                        local line = string.format(
                            "-- |N|Gossip Info - %d, %s, %s|",
                            i,
                            OneLine(opt.name or "Unknown"),
                            tostring(opt.gossipOptionID or "nil")
                        )
                        table.insert(RecorderDB.Record, line)
                    end
                    ns:Print(L["Gossip info added."])
                    UpdateLogWindow()
                else
                    ns:Print(L["No gossip options available."])
                end
            else
                ns:Print(L["Gossip API not available."])
            end
        -- elseif input and input:sub(1, 3) == "emt" then
        --     local uiMapID = tonumber(input:match("^emt%s+(%d+)$"))
        --     local uiMapArtID = C_Map.GetMapArtID(uiMapID)
        --     if not uiMapID then
        --         ns:Print("Usage: /rec emt <uiMapID>")
        --         return
        --     end

        --     local textures = C_MapExplorationInfo.GetExploredMapTextures(uiMapID)
        --     if textures and #textures > 0 then
        --         RecorderDB.Record = RecorderDB.Record or {}
        --         RecorderDB.Record[uiMapArtID] = RecorderDB.Record[uiMapArtID] or {}

        --         for _, tex in ipairs(textures) do
        --             local key = tex.textureWidth * 2^39 + tex.textureHeight * 2^26 + tex.offsetX * 2^13 + tex.offsetY

        --             local value = table.concat(tex.fileDataIDs, ",")

        --             RecorderDB.Record[uiMapArtID][key] = value
        --         end

        --         ns:Print("Exploration textures recorded for mapID " .. uiMapID)
        --     else
        --         ns:Print("No textures found for mapID " .. uiMapID)
        --     end
        end
    end

    frame:RegisterEvent("PLAYER_ENTERING_WORLD")
    frame:RegisterEvent("ENCOUNTER_START")
    frame:RegisterEvent("SCENARIO_UPDATE")
    frame:RegisterEvent("SCENARIO_CRITERIA_UPDATE")
    frame:RegisterEvent("QUEST_ACCEPTED")
    frame:RegisterEvent("QUEST_COMPLETE")
    frame:RegisterEvent("QUEST_AUTOCOMPLETE")
    frame:RegisterEvent("QUEST_TURNED_IN")
    frame:SetScript("OnEvent", function(_, event, ...) Recorder:HandleEvent(event, ...) end)

elseif (ns.ClassicEra or ns.TBC or ns.Wrath or ns.Cataclysm or ns.MOP) then

    local logFrame=CreateFrame("Frame","RecorderLogFrame",UIParent,"BasicFrameTemplateWithInset")
    logFrame:SetSize(600,400)
    logFrame:SetPoint("CENTER")
    logFrame:Hide()
    logFrame:SetMovable(true)
    if logFrame.SetResizable then
        if ns.CLASSICERA then
            logFrame:SetResizable(true)
        else
            logFrame:SetResizable(true)
            if logFrame.SetResizeBounds then
                logFrame:SetResizeBounds(400,200,1000,800)
            end
        end
    end
    logFrame:SetClampedToScreen(true)
    logFrame:EnableMouse(true)
    logFrame:RegisterForDrag("LeftButton")
    logFrame:SetScript("OnDragStart",function(self) self:StartMoving() end)
    logFrame:SetScript("OnDragStop",function(self) self:StopMovingOrSizing() end)

    local titleParent=logFrame.TitleBg or logFrame
    logFrame.title=logFrame:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    logFrame.title:SetPoint("LEFT",titleParent,"LEFT",5,0)
    logFrame.title:SetText(L["Recorder Log"])

    local scrollFrame=CreateFrame("ScrollFrame",nil,logFrame,"UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT",10,-50)
    scrollFrame:SetPoint("BOTTOMRIGHT",-30,40)

    local editBox=CreateFrame("EditBox",nil,scrollFrame)
    editBox:SetMultiLine(true)
    editBox:SetFontObject("ChatFontNormal")
    editBox:SetAutoFocus(false)
    editBox:EnableMouse(true)
    editBox:SetWidth(540)
    editBox:SetScript("OnEscapePressed",editBox.ClearFocus)
    editBox:SetScript("OnEditFocusGained",function(self) self:HighlightText() end)
    editBox:SetScript("OnMouseDown",function(self) if not self:HasFocus() then self:SetFocus() end end)
    scrollFrame:SetScrollChild(editBox)

    local clearBtn=CreateFrame("Button",nil,logFrame,"UIPanelButtonTemplate")
    clearBtn:SetSize(80,18)
    clearBtn:SetPoint("RIGHT",titleParent,"RIGHT",-25,0)
    clearBtn:SetText(L["Clear"])
    clearBtn:SetScript("OnClick",function()
        RecorderDB.Record={}
        editBox:SetText("")
        ns:Print(L["Record log has been cleared."])
    end)

    local resizer=CreateFrame("Button",nil,logFrame)
    resizer:SetPoint("BOTTOMRIGHT",logFrame,"BOTTOMRIGHT",-6,7)
    resizer:SetSize(16,16)
    resizer:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    resizer:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    resizer:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    resizer:SetScript("OnMouseDown",function(self,button)
        if button=="LeftButton" then
            logFrame:StartSizing("BOTTOMRIGHT")
            local ht=self:GetHighlightTexture()
            if ht then ht:Hide() end
        end
    end)
    resizer:SetScript("OnMouseUp",function(self,button)
        if button=="LeftButton" then
            logFrame:StopMovingOrSizing()
            local ht=self:GetHighlightTexture()
            if ht then ht:Show() end
        end
    end)

    scrollFrame:SetScript("OnSizeChanged",function(_,w,h)
        if w and w>40 then editBox:SetWidth(w-20) end
        if h and h>40 then editBox:SetHeight(h-20) end
    end)

    local function UpdateLogWindow()
        if RecorderDB and RecorderDB.Record and #RecorderDB.Record>0 then
            local out={}
            for i=1,#RecorderDB.Record do out[i]=EscapePipes(RecorderDB.Record[i]) end
            editBox:SetText(table.concat(out,"\n"))
            editBox:HighlightText(0,0)
        else
            editBox:SetText("")
        end
    end

    local function GetTargetNPC()
        local npcName=UnitName("target")
        local guid=UnitGUID("target")
        local npcID
        if guid then
            local _,_,_,_,_,id=strsplit("-",guid)
            npcID=tonumber(id)
        end
        return npcName,npcID
    end

    local function FormatCoords(zoneID)
        if C_Map and C_Map.GetPlayerMapPosition then
            local pos=C_Map.GetPlayerMapPosition(zoneID or 0,"player")
            if not pos then return 0,0 end
            local x,y=pos:GetXY()
            return x*100,y*100
        end
        return 0,0
    end

    local function AddQuestEntry(prefix,questID,questName)
        local zoneID=(C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")) or 0
        local mapInfo=C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(zoneID)
        local zoneName=mapInfo and mapInfo.name or "Unknown Zone"
        local x,y=FormatCoords(zoneID)
        local npcName,npcID=GetTargetNPC()
        local entry
        if prefix=="A" or prefix=="T" then
            entry=string.format("%s %s |QID|%d|N|Speak to %s in {%s} (%.2f,%.2f)|Z|%d|NPC|%s|",prefix,OneLine(questName),questID,OneLine(npcName or "Unknown"),OneLine(zoneName),x,y,zoneID,npcID or "?")
        elseif prefix=="C" then
            if C_QuestLog and C_QuestLog.GetQuestObjectives then
                local objectives=C_QuestLog.GetQuestObjectives(questID)
                if objectives and #objectives>0 then
                    for i,obj in ipairs(objectives) do
                        local t=obj.text or ("Objective "..i)
                        local qidx=string.format("%d.%d",questID,i)
                        entry=string.format("%s %s |QID|%s|N|%s in {%s} (%.2f,%.2f)|Z|%d|",prefix,OneLine(questName),qidx,OneLine(t),OneLine(zoneName),x,y,zoneID)
                    end
                else
                    entry=string.format("%s %s |QID|%d|N|Objective in {%s} (%.2f,%.2f)|Z|%d|",prefix,OneLine(questName),questID,OneLine(zoneName),x,y,zoneID)
                end
            end
        end
        entry=OneLine(entry)
        RecorderDB.Record=RecorderDB.Record or {}
        table.insert(RecorderDB.Record,entry)
        UpdateLogWindow()
    end

    function Recorder:HandleEvent(event,...)
        if not recorderEnabled then return end
        if event=="PLAYER_ENTERING_WORLD" then
            C_Timer.After(2,function()
                local instanceName,_,difficultyID,_,_,_,_,instanceID=GetInstanceInfo()
                local mapID=C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
                local _,_,_,difficultyName=GetInstanceInfo()
                local difficultyLabel=difficultyName or "Unknown"
                if not mapID or not instanceID or mapID==0 or instanceID==0 then return end
                local entry=string.format("-- |N|%s Instance Entered - %s [%s] (instanceID=%d)|Z|%d|",OneLine(instanceName or "Unknown"),OneLine(instanceName or "Unknown"),difficultyLabel,instanceID,mapID)
                entry=OneLine(entry)
                RecorderDB.Record=RecorderDB.Record or {}
                table.insert(RecorderDB.Record,entry)
                UpdateLogWindow()
            end)
            return
        end
        if event=="QUEST_ACCEPTED" or event=="QUEST_COMPLETE" or event=="QUEST_AUTOCOMPLETE" or event=="QUEST_TURNED_IN" then
            local questID=...
            if not questID or questID==0 then
                if C_QuestLog and C_QuestLog.GetNumQuestLogEntries then
                    local count=C_QuestLog.GetNumQuestLogEntries()
                    for i=1,count do
                        local info=C_QuestLog.GetInfo(i)
                        if info and (info.isCompleted or info.isAutoComplete) then questID=info.questID break end
                    end
                end
            end
            if not questID or questID==0 then return end
            local questName=(C_QuestLog and C_QuestLog.GetTitleForQuestID and C_QuestLog.GetTitleForQuestID(questID)) or "Unknown Quest"
            local prefix=event=="QUEST_ACCEPTED" and "A" or (event=="QUEST_TURNED_IN" and "T" or "C")
            AddQuestEntry(prefix,questID,questName)
            return
        end
    end

    function Recorder:OnInitialize()
        RecorderDB=RecorderDB or {}
        RecorderDB.Record=RecorderDB.Record or {}
        RecorderDB.enabled=RecorderDB.enabled~=false
        self:RegisterChatCommand("rec","HandleRecorder")
    end

    function Recorder:OnEnable()
        self:RegisterChatCommand("rec","HandleRecorder")
    end

    function Recorder:OnDisable()
        frame:UnregisterAllEvents()
        self:UnregisterChatCommand("rec")
    end

    function Recorder:EnableRecorder()
        recorderEnabled=true
        ns:Print(L["Recorder enabled."])
    end

    function Recorder:DisableRecorder()
        frame:UnregisterAllEvents()
        recorderEnabled=false
        ns:Print(L["Recorder disabled."])
    end

    function Recorder:HandleRecorder(input)
        if input=="on" then
            Recorder:EnableRecorder()
        elseif input=="off" then
            Recorder:DisableRecorder()
        elseif input=="clear" then
            RecorderDB.Record={}
            ns:Print(L["Record log has been cleared."])
            UpdateLogWindow()
        elseif input=="log" then
            if logFrame:IsShown() then logFrame:Hide() else UpdateLogWindow() logFrame:Show() end
        elseif input and input:sub(1,5)=="note " then
            local noteText=input:sub(6)
            if noteText and noteText~="" then
                RecorderDB.Record=RecorderDB.Record or {}
                local zoneID=(C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")) or 0
                local x,y=FormatCoords(zoneID)
                local mapInfo=C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(zoneID)
                local zoneName=mapInfo and mapInfo.name or "Unknown Zone"
                local formattedNote=string.format("-- |N|%s in {%s} (%.2f, %.2f)|Z|%d|",OneLine(noteText),OneLine(zoneName),x,y,zoneID)
                formattedNote=OneLine(formattedNote)
                table.insert(RecorderDB.Record,formattedNote)
                ns:Print(L["Note added."])
                UpdateLogWindow()
            else
                ns:Print(L["Usage: /rec note <your message>"])
            end
        else
            ns:Print(L["Usage: /rec on | off | clear | log | note <your message>"])
        end
    end

    frame:RegisterEvent("PLAYER_ENTERING_WORLD")
    frame:RegisterEvent("QUEST_ACCEPTED")
    frame:RegisterEvent("QUEST_COMPLETE")
    frame:RegisterEvent("QUEST_AUTOCOMPLETE")
    frame:RegisterEvent("QUEST_TURNED_IN")
    frame:SetScript("OnEvent",function(_,event,...) Recorder:HandleEvent(event,...) end)
end